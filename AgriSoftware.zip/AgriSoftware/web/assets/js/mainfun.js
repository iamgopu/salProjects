


$('#example').DataTable( {
    fixedHeader: true
} );

function getselectedgraph(){
    
document.getElementById("myChart").innerHTML = "";
 var finyr=document.getElementById("Financialyr").value;
       var feature =document.getElementById("Feature").textContent; 
    $.ajax({
		url: "Mainservlet",
		method: "GET",
                  data: {Action: "graphdata",Finyr: finyr,feature: feature },
		success: function(data) {
                      
                 var nobrack=   data.replace(/[\[\]']+/g,'');
			var m=nobrack.split(' -- ');
                      
             var  Month = m[0].split(',');
             
               var  Actual= m[1].split(',');
                 
               var   Budget= m[2].split(',');
         new Chart(document.getElementById("myChart"), {
    type: 'bar',
    data: {
      labels: Month,
      datasets: [{
          label: "Budget",
          type: "line",
          borderColor: "#00a0f5",
          data: Budget,
          fill: false
        },{
          label: "Actual",
          type: "bar",
          backgroundColor: "#fa0050",
          backgroundColorHover: "#3e95cd",
          data: Actual,
          fill: false
        }
      ]
    },
    options: {
      title: {
        display: false,
        text: 'Population growth (millions): Europe & Africa'
      },
      legend: { display: true }
    }
});
                },
error: function (xhr, ajaxOptions, thrownError) 
{ 
alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " +      thrownError);
}
});
   
}
function getselectedgraph1(){
    
document.getElementById("myChart1").innerHTML = "";
var financialyr=document.getElementById("Financialyr").value;
  var f=financialyr.split('-');
 var f1 = parseInt(f[0])-1;
 var f2 = parseInt(f[1])-1;
 
var finyr=f1.toString()+"-"+f2.toString();
       var feature =document.getElementById("Feature").textContent; 
    $.ajax({
		url: "Mainservlet",
		method: "GET",
                  data: {Action: "graphdata",Finyr: finyr,feature: feature },
		success: function(data) {
                      
                 var nobrack=   data.replace(/[\[\]']+/g,'');
			var m=nobrack.split(' -- ');
                      
             var  Month = m[0].split(',');
             
               var  Actual= m[1].split(',');
                 
               var   Budget= m[2].split(',');
         new Chart(document.getElementById("myChart1"), {
    type: 'bar',
    data: {
      labels: Month,
      datasets: [{
          label: "Budget",
          type: "line",
          borderColor: "#FF0000",
          data: Budget,
          fill: false
        },{
          label: "Actual",
          type: "bar",
          backgroundColor: "#0079dc",
          backgroundColorHover: "#3e95cd",
          data: Actual,
          fill: false
        }
      ]
    },
    options: {
      title: {
        display: false,
        text: 'Population growth (millions): Europe & Africa'
      },
      legend: { display: true }
    }
});
                },
error: function (xhr, ajaxOptions, thrownError) 
{ 
alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " +      thrownError);
}
});
   
}

