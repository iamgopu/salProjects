var ID = 0;

//openmodal function


function openmodaltaluka() {
    ID = "0";
    document.getElementById("talukaform").reset();
    document.getElementById("savetaluka").textContent = "Save";
    $('#myModal1').modal('toggle');
    getRegionDatafortaluka();
}
function openmodaldistrict() {
    ID = "0";
    document.getElementById("districtform").reset();
    document.getElementById("savedistrict").textContent = "Save";
    $('#myModal2').modal('toggle');

    getRegionDatafordistrict();
}
function openmodalstate() {
    ID = "0";
    document.getElementById("stateform").reset();
    document.getElementById("savestate").textContent = "Save";
    $('#myModal3').modal('toggle');
    getRegionDataDDL();
}
function openmodalregion() {
    document.getElementById("regionform").reset();
    document.getElementById("saveregion").textContent = "Save";
    $('#myModal4').modal('toggle');
}
//Save Functions

function SaveCategory()
{
    if (document.forms["categoryform"]["categoryName"].value == "") {
        alert("Please enter category name");
    } else {
        var Category_Name = document.getElementById("categoryName").value;
        var user = document.getElementById("user").textContent;
        $.ajax({
            type: "POST",
            url: "Agrimgmt",
            data: {action: "saveCategory", categoryName: Category_Name, user: user, Id: ID},
            success: function (data) {
                alert(data);
                getCategoryTableData();
            },
            error: function (xhr, ajaxOptions, thrownError)
            {
                alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
            }
        });
    }
}

function SaveCustomer()
{
    if (document.forms["customerform"]["address"].value == "") {
        alert("Please Enter Address");
    } else if (document.forms["customerform"]["City"].value == "") {
        alert("Please Enter City");
    } else if (document.forms["customerform"]["Pincode"].value == ".") {
        alert("Please Enter Correct Pincode");
    } else if (document.forms["customerform"]["State"].value == "") {
        alert("Please Enter State");
    } else if (document.forms["customerform"]["GST_Code"].value == "") {
        alert("Please Enter GST_Code");
    } else if (document.forms["customerform"]["GSTIN"].value == "") {
        alert("Please Enter GSTIN");
    } else if (document.forms["customerform"]["PanNo"].value == "") {
        alert("Please Enter PanNo");
    } else {
        var Customer_Name = document.getElementById("Customer_Name").value;
        var Address = document.getElementById("address").value;
        var City = document.getElementById("City").value;
        var Pincode = document.getElementById("Pincode").value;
        var State = document.getElementById("State").value;
        var GST_Code = document.getElementById("GST_Code").value;
        var GSTIN = document.getElementById("GSTIN").value;
        var PanNo = document.getElementById("PanNo").value;
        var user = document.getElementById("user").textContent;
        $.ajax({
            type: "POST",
            url: "Agrimgmt",
            data: {action: "saveCustomer", cname: Customer_Name, address: Address, city: City, pincode: Pincode, state: State, gstCode: GST_Code, gstin: GSTIN, PanNo: PanNo, user: user, Id: ID},
            success: function (data) {
                alert(data);
                getCustomerTableData();
            },
            error: function (xhr, ajaxOptions, thrownError)
            {
                alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
            }
        });
    }
}

function saveSetup()
{
    var email = document.getElementById("email").value;
    var emailId = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var mobNo = document.getElementById("mobNo").value;
    var reg = /^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/;
    if (document.forms["setupform"]["companyName"].value == "") {
        alert("Please enter company name");
    } else if (reg.test(mobNo) == false) {
        alert("Please enter valid mobile number");
    } else if (emailId.test(email) == false) {
        alert("Please enter valid email id");
    } else if (document.forms["setupform"]["state"].value == "") {
        alert("Please enter state");
    } else if (document.forms["setupform"]["gstin"].value == "") {
        alert("Please enter gstin");
    } else if (document.forms["setupform"]["panNo"].value == "") {
        alert("Please enter Pan Number");
    } else if (document.forms["setupform"]["address"].value == "") {
        alert("Please enter address");
    } else if (document.forms["setupform"]["Account_Name"].value == "") {
        alert("Please enter Account_Name");
    } else if (document.forms["setupform"]["Bank_Name"].value == "") {
        alert("Please enter Bank_Name");
    } else if (document.forms["setupform"]["Account_Number"].value == "") {
        alert("Please enter Account_Number");
    } else if (document.forms["setupform"]["Branch_Name"].value == "") {
        alert("Please enter Branch_Name");
    } else if (document.forms["setupform"]["IFSC_Code"].value == "") {
        alert("Please enter IFSC_Code");
    } else {
        var CompanyName = document.getElementById("companyName").value;
        var MobileNo = document.getElementById("mobNo").value;
        var Email = document.getElementById("email").value;
        var State = document.getElementById("state").value;
        var GSTIN = document.getElementById("gstin").value;
        var PanNo = document.getElementById("panNo").value;
        var Address = document.getElementById("address").value;
        var Account_Name = document.getElementById("Account_Name").value;
        var Bank_Name = document.getElementById("Bank_Name").value;
        var Account_Number = document.getElementById("Account_Number").value;
        var Branch_Name = document.getElementById("Branch_Name").value;
        var IFSC_Code = document.getElementById("IFSC_Code").value;
        $.ajax({
            type: "POST",
            url: "Agrimgmt",
            data: {action: "saveSetup", CompanyName: CompanyName, MobileNo: MobileNo, Email: Email, State: State,
                GSTIN: GSTIN, PanNo: PanNo, Address: Address, acname: Account_Name, bankname: Bank_Name, acnumber: Account_Number, bname: Branch_Name, ifsc: IFSC_Code, Id: ID},
            success: function (data) {
                alert(data);
            },
            error: function (xhr, ajaxOptions, thrownError)
            {
                alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
            }

        });
    }
}

function SaveRegion()
{
    if (document.forms["regionform"]["Region"].value == "") {
        alert("Please Enter Region Name");
    } else {
        var Region = document.getElementById("Region").value;
        var user = document.getElementById("user").textContent;
        $.ajax({
            type: "POST",
            url: "Agrimgmt",
            data: {action: "saveRegion", Region: Region, user: user, Id: ID},
            success: function (data) {
                alert(data);
                getRegionTableData();
                $('#myModal4').modal('toggle');
            },
            error: function (xhr, ajaxOptions, thrownError)
            {
                alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
            }

        });
    }
}

function SaveState()
{
    if (document.forms["stateform"]["SRegionId"].value == "0") {
        alert("Please Select Region");

    } else if (document.forms["stateform"]["stateinput"].value == "") {
        alert("Please enter state name");

    } else {
        var regionId = document.getElementById("SRegionId").value;
        var state = document.getElementById("stateinput").value;
        var user = document.getElementById("user").textContent;
        $.ajax({
            type: "POST",
            url: "Agrimgmt",
            data: {action: "saveState", regionId: regionId, state: state, user: user, Id: ID},
            success: function (data) {
                alert(data);
                getStateTableData();
                $('#myModal3').modal('toggle');
            },
            error: function (xhr, ajaxOptions, thrownError)
            {
                alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
            }

        });
    }
}

function SaveDistrict()
{
    if (document.forms["districtform"]["DRegionId"].value == "0") {
        alert("Please Select Region");

    } else if (document.forms["districtform"]["DstateId"].value == "0") {
        alert("Please Select District");

    } else if (document.forms["districtform"]["districtinput"].value == "") {
        alert("Please enter district name");

    } else {
        var stateId = document.getElementById("DstateId").value;
        var district = document.getElementById("districtinput").value;
        var user = document.getElementById("user").textContent;

        $.ajax({
            type: "POST",
            url: "Agrimgmt",
            data: {action: "saveDistrict", stateId: stateId, district: district, user: user, Id: ID},
            success: function (data) {
                alert(data);
                getDistrictTableData();
                $('#myModal2').modal('toggle');
            },
            error: function (xhr, ajaxOptions, thrownError)
            {
                alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
            }

        });
    }
}

function SaveTaluka()
{
    if (document.forms["talukaform"]["TRegionId"].value == "0") {
        alert("Please Select Region");

    } else if (document.forms["talukaform"]["stateId"].value == "0") {
        alert("Please Select State");

    } else if (document.forms["talukaform"]["districtId"].value == "0") {
        alert("Please Select District");

    } else if (document.forms["talukaform"]["Talukainput"].value == "") {
        alert("Please Enter Taluka Name");

    } else {
        var districtId = document.getElementById("districtId").value;
        var Taluka = document.getElementById("Talukainput").value;
        var user = document.getElementById("user").textContent;

        $.ajax({
            type: "POST",
            url: "Agrimgmt",
            data: {action: "saveTaluka", districtId: districtId, Taluka: Taluka, user: user, Id: ID},
            success: function (data) {
                alert(data);
                getTalukaTableData();
                $('#myModal1').modal('toggle');
            },
            error: function (xhr, ajaxOptions, thrownError)
            {
                alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
            }

        });
    }
}

function saveUOM()
{
    var UOM = document.getElementById("uom").value;
    var type = document.getElementById("type").value;
    var user = document.getElementById("user").textContent;

    $.ajax({
        type: "POST",
        url: "Agrimgmt",
        data: {action: "saveUOM", UOM: UOM, type: type, user: user, Id: ID},
        success: function (data) {
            alert(data);
            getUomTableData();

        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function savePlanningForm()
{
    if (document.forms["planningform"]["FarmerId"].value == "0") {
        alert("Please Select Farmer Name");
    } else if (document.forms["planningform"]["LandId"].value == "0") {
        alert("Please Select Land");
    } else if (document.forms["planningform"]["CropId"].value == "0") {
        alert("Please Select Crop");
    } else if (document.forms["planningform"]["GradeId"].value == "0") {
        alert("Please Select Grade");
    } else if (document.forms["planningform"]["TotalSeedsPlanted"].value == "") {
        alert("Please Enter Amount of seed Planted");
    } else if (document.forms["planningform"]["PlantationArea"].value == "") {
        alert("Please Enter Plantation Area");
    } else {
        var FarmerId = document.getElementById("FarmerId").value;
        var LandId = document.getElementById("LandId").value;
        var CropId = document.getElementById("CropId").value;
        var GradeId = document.getElementById("GradeId").value;
        var TotalSeedsPlanted = document.getElementById("TotalSeedsPlanted").value;
        var PlantationArea = document.getElementById("PlantationArea").value;
        var PlanningDate = document.getElementById("PlanningDate").value;
        var user = document.getElementById("user").textContent;
        $.ajax({
            type: "POST",
            url: "Agrimgmt",
            data: {action: "savePlanning", FarmerId: FarmerId, LandId: LandId, CropId: CropId, GradeId: GradeId, TotalSeedsPlanted: TotalSeedsPlanted, PlantationArea: PlantationArea, PlanningDate: PlanningDate, user: user, Id: ID},
            success: function (data) {
                alert(data);
                getPlanningTableData();
            },
            error: function (xhr, ajaxOptions, thrownError)
            {
                alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
            }

        });
    }
}


//Edit Functions

function getcategorydataforedit(Id) {
    document.getElementById("saveCategory").textContent = "UPDATE";
    ID = Id;
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "GetCategoryData", Id: ID},
        success: function (data) {
            $('#myModal3').modal('toggle');
            var data1 = data.split(" -- ");
            document.getElementById("categoryName").value = data1[0];
            if (data1[1] == "null" || data1[1] == "" || data1[1] == null) {
                document.getElementById("Lastupdateddetails").textContent = "Not revised";
            } else {
                document.getElementById("Lastupdateddetails").textContent = data1[1];
            }
            ID = data1[2];
            document.getElementById('Fid').textContent = "Cat_Id : " + ID;
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }


    });

}

function getcustomerdataforedit(id) {
    document.getElementById("savecustomer").textContent = "UPDATE";
    ID = id;
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "GetCustomerData", Id: ID},
        success: function (data) {
            $('#myModal').modal('toggle');
            var data1 = data.split(" -- ");
            document.getElementById("Customer_Name").value = data1[0];
            document.getElementById("address").value = data1[1];
            document.getElementById("City").value = data1[2];
            document.getElementById("Pincode").value = data1[3];
            document.getElementById("State").value = data1[4];
            document.getElementById("GST_Code").value = data1[5];
            document.getElementById("GSTIN").value = data1[6];
            document.getElementById("PanNo").value = data1[7];
            if (data1[8] == "null" || data1[8] == "" || data1[8] == null) {
                document.getElementById("Lastupdateddetails").textContent = "Not Updated";
            } else {
                document.getElementById("Lastupdateddetails").textContent = data1[8];
            }
            ID = data1[9];
            document.getElementById('Fid').textContent = "Customer_Id : " + ID;
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getsetupforedit(Id) {
    document.getElementById("savesetup").textContent = "UPDATE";
    Id = "1";
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "GetSetupData", Id: Id},
        success: function (data) {
            var data1 = data.split(" -- ");
            document.getElementById("companyName").value = data1[0];
            document.getElementById("mobNo").value = data1[1];
            document.getElementById("email").value = data1[2];
            document.getElementById("state").value = data1[3];
            document.getElementById("gstin").value = data1[4];
            document.getElementById("panNo").value = data1[5];
            document.getElementById("address").value = data1[6];
            document.getElementById("Account_Name").value = data1[7];
            document.getElementById("Bank_Name").value = data1[8];
            document.getElementById("Account_Number").value = data1[9];
            document.getElementById("Branch_Name").value = data1[10];
            document.getElementById("IFSC_Code").value = data1[11];
            Id = data1[12];

        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getregionforedit(Id) {
    document.getElementById("saveregion").textContent = "UPDATE";
    ID = Id;
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "GetRegionData", Id: ID},
        success: function (data) {
            var data1 = data.split(" -- ");
            Region = document.getElementById("Region").value = data1[0];
            document.getElementById('Fid').textContent = "Region_Id : " + ID;
            $('#myModal4').modal('toggle');
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getstateforedit(Id) {
    document.getElementById("savestate").textContent = "UPDATE";
    ID = Id;
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "GetStateData", Id: ID},
        success: function (data) {
            var data1 = data.split(" -- ");
            getRegionDataDDL();
            setTimeout(function () {
                document.getElementById("SRegionId").value = data1[0];
                document.getElementById("stateinput").value = data1[1];
                document.getElementById('Fid').textContent = "State_Id : " + ID;
                $('#myModal3').modal('toggle');
            }, 500);
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });


}

function getdistrictforedit(Id) {
    document.getElementById("savedistrict").textContent = "UPDATE";
    ID = Id;
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "GetDistrictData", Id: ID},
        success: function (data) {
            var data1 = data.split(" -- ");
            getRegionDatafordistrict();

            getStateDataDDL(data1[2]);
            setTimeout(function () {
                document.getElementById("DRegionId").value = data1[2];

                document.getElementById("DstateId").value = data1[0];

                document.getElementById("districtinput").value = data1[1];

                document.getElementById('Fid').textContent = "Dist_Id : " + ID;

                $('#myModal2').modal('toggle');
            }, 500);

        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function gettalukaforedit(Id) {
    document.getElementById("savetaluka").textContent = "UPDATE";
    ID = Id;
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "GetTalukaData", Id: ID},
        success: function (data) {

            var data1 = data.split(" -- ");

            getRegionDatafortaluka();
            getStateDatafortaluka(data1[0]);
            getDistrictData(data1[1]);

            setTimeout(function () {
                document.getElementById("TRegionId").value = data1[0];
                document.getElementById("TstateId").value = data1[1];
                document.getElementById("districtId").value = data1[2];
                document.getElementById("Talukainput").value = data1[3];
                document.getElementById('Fid').textContent = "Tq_Id : " + ID;
                $('#myModal1').modal('toggle');
            }, 500);

        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getuomdataforedit(id) {

    document.getElementById("saveuom").textContent = "UPDATE";
    ID = id;
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "GetUomData", Id: ID},
        success: function (data) {
            $('#myModal3').modal('toggle');
            var data1 = data.split(" -- ");
            document.getElementById("uom").value = data1[0];
            document.getElementById("type").value = data1[1];
            ID = data1[2];
            document.getElementById('Fid').textContent = "UOM_Id : " + ID;
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }


    });

}

function getplanningdataforedit(id) {
    document.getElementById("savePlanning").textContent = "UPDATE";
    ID = id;
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "GetPlanningData", Id: ID},
        success: function (data) {
            getFarmerDataforPlanning();
            getCropDataforPlanning();

            var data1 = data.split(" -- ");


            getLandDataforPlanning(data1[0]);
            getGradeDataforPlanning(data1[2]);

            setTimeout(function () {
                document.getElementById("FarmerId").value = data1[0];
                document.getElementById("LandId").value = data1[1];
                document.getElementById("CropId").value = data1[2];
                document.getElementById("GradeId").value = data1[3];
                $('#myModal').modal('toggle');
            }, 1000);

            document.getElementById("TotalSeedsPlanted").value = data1[4];
            document.getElementById("PlantationArea").value = data1[5];
            document.getElementById("PlanningDate").value = data1[6];



            if (data1[8] == "null" || data1[8] == "" || data1[8] == null) {
                document.getElementById("Lastupdateddetails").textContent = "Not Updated";
            } else {
                document.getElementById("Lastupdateddetails").textContent = data1[7] + " " + data1[8];
            }
            ID = data1[9];
            document.getElementById('Fid').textContent = "Plan_Id : " + ID;

        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getprocurementdataforedit(id) {
    document.getElementById("saveProcurement").textContent = "UPDATE";
    ID = id;
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "GetProcurementData", Id: ID},
        success: function (data) {
            getFarmerDataforProcurement();
            getCropDataforProcurement();

            var data1 = data.split(" -- ");


            getLandDataforProcurement(data1[0]);
            getGradeDataforProcurement(data1[2]);

            setTimeout(function () {
                document.getElementById("FarmerId").value = data1[0];
                document.getElementById("LandId").value = data1[1];
                document.getElementById("CropId").value = data1[2];
                document.getElementById("GradeId").value = data1[3];
                $('#myModal').modal('toggle');
            }, 1000);

            document.getElementById("TotalSeedsPlanted").value = data1[4];
            document.getElementById("PlantationArea").value = data1[5];
            document.getElementById("PlanningDate").value = data1[6];



            if (data1[8] == "null" || data1[8] == "" || data1[8] == null) {
                document.getElementById("Lastupdateddetails").textContent = "Not Updated";
            } else {
                document.getElementById("Lastupdateddetails").textContent = data1[7] + " " + data1[8];
            }
            ID = data1[9];
            document.getElementById('Fid').textContent = "Pro_Id : " + ID;
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}



//GetTableData

function getCategoryTableData()
{
    var username = localStorage.getItem("user");
    document.getElementById("user").innerHTML = username;
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "categoryTable"},
        success: function (data) {

            $("#tblcontainer").html(data);
            $('#example').DataTable({
                fixedHeader: true
            });
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }


    });
}

function getCustomerTableData()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "CustomerTable"},
        success: function (data) {
            $("#tblcontainer").html(data);
            $('#example').DataTable({
                fixedHeader: true
            });
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}


function getRegionTableData()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "RegionTable"},
        success: function (data) {
            $("#tblcontainer4").html(data);
            $('#example4').DataTable({
                fixedHeader: true
            });
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getStateTableData()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "StateTable"},
        success: function (data) {
            $("#tblcontainer3").html(data);
            $('#example3').DataTable({
                fixedHeader: true
            });
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getDistrictTableData()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "DistrictTable"},
        success: function (data) {
            $("#tblcontainer2").html(data);
            $('#example2').DataTable({
                fixedHeader: true
            });
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getTalukaTableData()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "TalukaTable"},
        success: function (data) {
            $("#tblcontainer1").html(data);
            $('#example1').DataTable({
                fixedHeader: true
            });
        }
    });
}

function getUomTableData()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "UOMTable"},
        success: function (data) {
            $("#tblcontainer").html(data);
            $('#example').DataTable({
                fixedHeader: true
            });
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}



//Delete Functions



function DeleteCustomer(Id) {
    var result = confirm("Are you sure to delete");
    if (result) {
        $.ajax({
            type: "POST",
            url: "Agrimgmt",
            data: {action: "Delete", Id: Id, tbl: "customermaster"},
            success: function (data) {
                alert(data);
                getCustomerTableData();
            },
            error: function (xhr, ajaxOptions, thrownError)
            {
                alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
            }
        });
    }
}

function DeleteRegion(Id) {

    checkregionbeforedelete(Id);

}

function checkregionbeforedelete(Id) {
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "checkRegionDelete", regionId: Id},
        success: function (data) {
            if (data == "0") {
                var result = confirm("Are you sure to delete");
                if (result) {
                    $.ajax({
                        type: "POST",
                        url: "Agrimgmt",
                        data: {action: "Delete", Id: Id, tbl: "regionmaster"},
                        success: function (data) {
                            alert(data);
                            getRegionTableData();
                        },
                        error: function (xhr, ajaxOptions, thrownError)
                        {
                            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
                        }
                    });
                }
            } else {
                alert("Data is already entered somewhere, please check");
            }

        }
    });
}

function DeleteState(Id) {

    checkstatebeforedelete(Id);

}

function checkstatebeforedelete(Id) {
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "checkStateDelete", stateId: Id},
        success: function (data) {
            if (data == "0") {
                var result = confirm("Are you sure to delete");
                if (result) {
                    $.ajax({
                        type: "POST",
                        url: "Agrimgmt",
                        data: {action: "Delete", Id: Id, tbl: "statemaster"},
                        success: function (data) {
                            alert(data);
                            getStateTableData();
                        },
                        error: function (xhr, ajaxOptions, thrownError)
                        {
                            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
                        }
                    });
                }
            } else {
                alert("Data is already entered somewhere, please check");
            }

        }
    });
}

function DeleteDistrict(Id) {

    checkdistrictbeforedelete(Id);

}

function checkdistrictbeforedelete(Id) {
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "checkDistrictDelete", districtId: Id},
        success: function (data) {
            if (data == "0") {
                var result = confirm("Are you sure to delete");
                if (result) {
                    $.ajax({
                        type: "POST",
                        url: "Agrimgmt",
                        data: {action: "Delete", Id: Id, tbl: "districtmaster"},
                        success: function (data) {
                            alert(data);
                            getDistrictTableData();
                        },
                        error: function (xhr, ajaxOptions, thrownError)
                        {
                            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
                        }
                    });
                }
            } else {
                alert("Data is already entered somewhere, please check");
            }

        }
    });
}

function DeleteTaluka(Id) {

    checktalukabeforedelete(Id);

}

function checktalukabeforedelete(Id) {
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "checkTalukaDelete", talukaId: Id},
        success: function (data) {
            if (data == "0") {
                var result = confirm("Are you sure to delete");
                if (result) {
                    $.ajax({
                        type: "POST",
                        url: "Agrimgmt",
                        data: {action: "Delete", Id: Id, tbl: "talukamaster"},
                        success: function (data) {
                            alert(data);
                            getTalukaTableData();
                        },
                        error: function (xhr, ajaxOptions, thrownError)
                        {
                            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
                        }
                    });
                }
            } else {
                alert("Data is already entered somewhere, please check");
            }

        }
    });
}



//Dropdown

function getRegionDataDDL()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "regiondistrict", regionId: "SRegionId"},
        success: function (data) {

            $("#regionddl").html(data);
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}
function getRegionDatafordistrict()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "regiondistrict", regionId: "DRegionId"},
        success: function (data) {

            $("#regionddl1").html(data);
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getRegionDatafortaluka()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "regiontaluka", regionId: "TRegionId"},
        success: function (data) {

            $("#regionddl2").html(data);
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}
function getStateDataDDL(regionid)
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "stateddl", regionId: regionid},
        success: function (data) {

            $("#stateddl1").html(data);

        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}
function getStateDataDDL(regionid)
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "stateddl", regionId: regionid, Stateid: "DstateId"},
        success: function (data) {

            $("#stateddl1").html(data);

        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}
function getStateDatafortaluka(regionid)
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "stateddl", regionId: regionid, Stateid: "TstateId"},
        success: function (data) {

            $("#stateddl").html(data);

        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getDistrictData(Stateid)
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "districtddl", Stateid: Stateid},
        success: function (data) {

            $("#districtddl").html(data);
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}


function getFarmerDataforPlanning()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "farmerddl"},
        success: function (data) {
            $("#farmerddl").html(data);

        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getLandDataforPlanning(FarmerId)
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "landddl", FarmerId: FarmerId},
        success: function (data) {
            $("#landddl").html(data);
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}

function getCropDataforPlanning()
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "cropddl"},
        success: function (data) {
            $("#cropddl").html(data);

        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}


function getGradeDataforPlanning(CropId)
{
    $.ajax({
        type: "GET",
        url: "Agrimgmt",
        data: {action: "gradeddl", CropId: CropId},
        success: function (data) {
            $("#gradeddl").html(data);
        },
        error: function (xhr, ajaxOptions, thrownError)
        {
            alert("errorstatus: " + xhr.status + " ajaxoptions: " + ajaxOptions + " throwError: " + thrownError);
        }
    });
}






