package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "Agrimgmt", urlPatterns = {"/Agrimgmt"})
public class Agrimgmt extends HttpServlet {

    Connection con = DBcon.getCon();
    java.util.Date curDate = new java.util.Date();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (null != action) {
            switch (action) {
                case "categoryTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr No.</th>\n"
                            + "                <th>Category Name</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from categorymaster order by id desc";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("categoryName") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br>" + rs.getString("EnteredDate") + "</br></td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" onClick=\"getcategorydataforedit(" + rs.getString("Id") + ")\">Edit</a>&nbsp"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"DeleteCategory(" + rs.getString("id") + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    break;
                }

                case "CustomerTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Customer Name</th>\n"
                            + "                <th>Address</th>\n"
                            + "                <th>City</th>\n"
                            + "                <th>Pincode</th>\n"
                            + "                <th>State</th>\n"
                            + "                <th>GST Code</th>\n"
                            + "                <th>GSTIN</th>\n"
                            + "                <th>PanNo</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from customermaster order by id desc";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("Customer_Name") + "</td>\n"
                                    + "                <td>" + rs.getString("Address") + "</td>\n"
                                    + "                <td>" + rs.getString("City") + "</td>\n"
                                    + "                <td>" + rs.getString("Pincode") + "</td>\n"
                                    + "                <td>" + rs.getString("State") + "</td>\n"
                                    + "                <td>" + rs.getString("GST_Code") + "</td>\n"
                                    + "                <td>" + rs.getString("GSTIN") + "</td>\n"
                                    + "                <td>" + rs.getString("PanNo") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" style=\"width:70px;\" onClick=\"getcustomerdataforedit(" + rs.getString("id") + ")\">Edit</a>"
                                    + "<a class=\"btn btn-danger btn-sm\" style=\"width:70px;\" onClick=\"DeleteCustomer(" + rs.getString("id") + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;

                case "RegionTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example4\" class=\"table table-striped table-bordered\" style=\"width:90%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>ID</th>\n"
                            + "                <th>Region</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Action</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from regionmaster order by id desc";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("Region") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " " + rs.getString("EnteredDate") + "<br/></td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" style=\"width:40%\" onClick=\"getregionforedit(" + rs.getString("Id") + ")\">Edit</a>&nbsp"
                                    + "<a class=\"btn btn-danger btn-sm\" style=\"width:40%\" onClick=\"DeleteRegion(" + rs.getString("Id") + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;

                case "StateTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example3\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>ID</th>\n"
                            + "                <th>Region</th>\n"
                            + "                <th>State</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Action</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select sm.id as ID,rm.region as region,state,sm.enteredby as EnteredBy,sm.EnteredDate as EnteredDate from statemaster sm "
                            + "left join regionmaster rm on (sm.regionid=rm.id) order by id desc";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("region") + "</td>\n"
                                    + "                <td>" + rs.getString("state") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" onClick=\"getstateforedit(" + rs.getString("ID") + ")\">Edit</a>&nbsp"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"DeleteState(" + rs.getString("ID") + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "DistrictTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example2\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>ID</th>\n"
                            + "                <th>State</th>\n"
                            + "                <th>District</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Action</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select dm.id as ID,sm.state as state,district,dm.enteredby as EnteredBy,dm.EnteredDate as EnteredDate from districtmaster dm "
                            + "left join statemaster sm on (dm.stateid=sm.id) order by id desc";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("state") + "</td>\n"
                                    + "                <td>" + rs.getString("district") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" onClick=\"getdistrictforedit(" + rs.getString("ID") + ")\">Edit</a>&nbsp"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"DeleteDistrict(" + rs.getString("ID") + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "TalukaTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example1\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>ID</th>\n"
                            + "                <th>State</th>\n"
                            + "                <th>District</th>\n"
                            + "                <th>Taluka</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Action</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select tm.id,sm.state,dm.district,taluka,tm.enteredby,tm.entereddate from talukamaster tm left join Districtmaster dm on (tm.DistrictId=dm.id) "
                            + " left join statemaster sm on (sm.id=dm.stateid) order by id desc";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + String.valueOf(i) + "</td>\n"
                                    + "                <td>" + rs.getString("state") + "</td>\n"
                                    + "                <td>" + rs.getString("district") + "</td>\n"
                                    + "                <td>" + rs.getString("Taluka") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" onClick=\"gettalukaforedit(" + rs.getString("Id") + ")\">Edit</a>&nbsp"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"DeleteTaluka(" + rs.getString("Id") + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "UOMTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>UOM</th>\n"
                            + "                <th>Type</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from uommaster order by id desc";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("uom") + "</td>\n"
                                    + "                <td>" + rs.getString("type") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" onClick=\"getuomdataforedit(" + rs.getString("id") + ") \">Edit</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;

                case "PlanningTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Farmer Name</th>\n"
                            + "                <th>Land</th>\n"
                            + "                <th>Crop</th>\n"
                            + "                <th>Grades</th>\n"
                            + "                <th>Total Seed Planted</th>\n"
                            + "                <th>Plantation Area</th>\n"
                            + "                <th>Planning Date</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select p.id,fm.FarmerName as farmer,fld.LandId as land,cid.crop as crop,cg.Grade as grade,TotalSeedsPlanted,PlantationArea,PlanningDate,p.EnteredBy,p.EnteredDate,p.RevisedBy,p.RevisedDate from planning p "
                            + "left join farmermaster fm on (p.FarmerId=fm.id)"
                            + " left join farmerlanddetails fld on (p.LandId = fld.id)"
                            + " left join cropmaster cid on (p.CropId = cid.id)"
                            + " left join cropgrades cg on (p.GradeId = cg.id) order by id desc";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("farmer") + "</td>\n"
                                    + "                <td>" + rs.getString("land") + "</td>\n"
                                    + "                <td>" + rs.getString("crop") + "</td>\n"
                                    + "                <td>" + rs.getString("grade") + "</td>\n"
                                    + "                <td>" + rs.getString("TotalSeedsPlanted") + "</td>\n"
                                    + "                <td>" + rs.getString("PlantationArea") + "</td>\n"
                                    + "                <td>" + rs.getString("PlanningDate") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><a class=\"btn btn-primary btn-sm\" onClick=\"getplanningdataforedit(" + rs.getString("id") + ")\">Edit</a>"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"DeletePlanning(" + rs.getString("id") + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "         ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "ProcurementTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Planning Id</th>\n"
                            + "                <th>Farmer Name</th>\n"
                            + "                <th>Land</th>\n"
                            + "                <th>Crop</th>\n"
                            + "                <th>Grades</th>\n"
                            + "                <th>Date</th>\n"
                            + "                <th>Qty</th>\n"
                            + "                <th>Rate</th>\n"
                            + "                <th>Vehicle No</th>\n"
                            + "                <th>Staff Name</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select p.id,fm.FarmerName as farmerName,fld.LandId as land,cid.crop as crop,cg.Grade as grade,um.UserId as StaffName,PlanningId,ProcurementDate,ProcurementQTY,Rate,VehicleNo,p.EnteredBy,p.EnteredDate,p.RevisedBy,p.RevisedDate from procurement p "
                            + "left join planning pl on (pl.id=p.PlanningId)"
                            + " left join farmermaster fm on(fm.id=pl.FarmerId) "
                            + "left join farmerlanddetails fld on(fld.id=pl.LandId)"
                            + " left join cropmaster cid on (cid.id = pl.CropId)"
                            + " left join cropgrades cg on (cg.id = pl.GradeId)"
                            + " left join usermaster um on (um.id = p.StaffName) order by id desc";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("PlanningId") + "</td>\n"
                                    + "                <td>" + rs.getString("farmerName") + "</td>\n"
                                    + "                <td>" + rs.getString("land") + "</td>\n"
                                    + "                <td>" + rs.getString("crop") + "</td>\n"
                                    + "                <td>" + rs.getString("grade") + "</td>\n"
                                    + "                <td>" + rs.getString("ProcurementDate") + "</td>\n"
                                    + "                <td>" + rs.getString("ProcurementQTY") + "</td>\n"
                                    + "                <td>" + rs.getString("Rate") + "</td>\n"
                                    + "                <td>" + rs.getString("VehicleNo") + "</td>\n"
                                    + "                <td>" + rs.getString("StaffName") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><a class=\"btn btn-primary btn-sm\" onClick=\"getprocurementdataforedit(" + rs.getString("id") + ")\">Edit</a>"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"Delete(" + rs.getString("id") + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "         ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "ProcurementTableForPayment": {
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    out.print("<table id=\"example1\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Farmer Name</th>\n"
                            + "                <th>Crop</th>\n"
                            + "                <th>Grades</th>\n"
                            + "                <th>Date</th>\n"
                            + "                <th>Quantity</th>\n"
                            + "                <th>Rate</th>\n"
                            + "                <th>Pay</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select p.id,fm.FarmerName as farmerName,cid.crop as crop,cg.Grade as grade,ProcurementDate,ProcurementQTY,Rate from procurement p "
                            + "left join planning pl on (pl.id=p.PlanningId)"
                            + " left join farmermaster fm on(fm.id=pl.FarmerId) "
                            + " left join cropmaster cid on (cid.id = pl.CropId)"
                            + " left join cropgrades cg on (cg.id = pl.GradeId) where p.close='0' order by id desc";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("farmerName") + "</td>\n"
                                    + "                <td>" + rs.getString("crop") + "</td>\n"
                                    + "                <td>" + rs.getString("grade") + "</td>\n"
                                    + "                <td>" + rs.getString("ProcurementDate") + "</td>\n"
                                    + "                <td>" + rs.getString("ProcurementQTY") + "</td>\n"
                                    + "                <td>" + rs.getString("Rate") + "</td>\n");
                            out.print("<td><a class=\"btn btn-primary\"  onclick=\"getprocurementdataforpayment(" + rs.getString("ID") + ")\">Make Payment</a></td>\n"
                                    + "            </tr>\n");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "ProcurementTableForPaid": {
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    out.print("<table id=\"example2\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Farmer Name</th>\n"
                            + "                <th>Crop</th>\n"
                            + "                <th>Grades</th>\n"
                            + "                <th>Quantity</th>\n"
                            + "                <th>Payment Date</th>\n"
                            + "                <th>Payable Amount</th>\n"
                            + "                <th>Paid Amount</th>\n"
                            + "                <th>Payment mode</th>\n"
                            + "                <th>Entered Details</th>\n"
                            + "                <th>Revised Details </th>\n"
                            + "                <th>Action</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select pay.id,fm.FarmerName as farmerName,cid.crop as crop,cg.Grade as grade,ProcurementQty as qty, Paymentdate,"
                            + "PayableAmount,paidAmount,Modeofpayment,pay.EnteredBy,pay.EnteredDate,pay.revisedby,"
                            + "pay.reviseddate from payment pay Left join procurement p on "
                            + "(p.id=pay.procurementid) left join planning pl on (pl.id=p.PlanningId) "
                            + "left join farmermaster fm on(fm.id=pl.FarmerId) "
                            + "left join cropmaster cid on (cid.id = pl.CropId) "
                            + "left join cropgrades cg on (cg.id = pl.GradeId) order by id desc";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("farmerName") + "</td>\n"
                                    + "                <td>" + rs.getString("crop") + "</td>\n"
                                    + "                <td>" + rs.getString("grade") + "</td>\n"
                                    + "                <td>" + rs.getString("qty") + "</td>\n"
                                    + "                <td>" + rs.getString("Paymentdate") + "</td>\n"
                                    + "                <td>" + rs.getString("PayableAmount") + "</td>\n"
                                    + "                <td>" + rs.getString("paidAmount") + "</td>\n"
                                    + " <td>" + rs.getString("Modeofpayment") + "</td>\n"
                                    + " <td>" + rs.getString("EnteredBy") + " <br>" + rs.getString("EnteredDate") + "</br></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><a class=\"btn btn-primary btn-sm\" onClick=\"getpaymentdataforedit(" + rs.getString("ID") + ")\">Edit</a></td>\n"
                                    + "            </tr>\n");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "VisitReportTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Visit Date</th>\n"
                            + "                <th>Village Id</th>\n"
                            + "                <th>Number Of Members</th>\n"
                            + "                <th>Village In-Charge</th>\n"
                            + "                <th>Training Details</th>\n"
                            + "                <th>Added Farmers</th>\n"
                            + "                <th>Conducted By</th>\n"
                            + "                <th>Conducted Date</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details </th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select vr.id,VisitDate,vm.Village as villagename,NoOfMember,VillageInCharge,AddedFarmers,um.UserId as user,ConductedDate,"
                            + "TrainingDetails,vr.EnteredBy,vr.EnteredDate,vr.RevisedBy,vr.RevisedDate from visitreport vr "
                            + "left join villagemaster vm on (vm.id=vr.VillageId) "
                            + "left join usermaster um on (um.id=vr.ConductedBy) order by id desc";
                   
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("visitdate") + "</td>\n"
                                    + "                <td>" + rs.getString("villagename") + "</td>\n"
                                    + "                <td>" + rs.getString("NoOfMember") + "</td>\n"
                                    + "                <td>" + rs.getString("villageincharge") + "</td>\n"
                                    + "                <td>" + rs.getString("trainingdetails") + "</td>\n"
                                    + "                <td>" + rs.getString("addedfarmers") + "</td>\n"
                                    + "                <td>" + rs.getString("user") + "</td>\n"
                                    + "                <td>" + rs.getString("conducteddate") + "</td>\n"
                                    + " <td>" + rs.getString("EnteredBy") + " <br>" + rs.getString("EnteredDate") + "</br></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><a class=\"btn btn-primary btn-sm\" onClick=\"getvisitdataforedit(" + rs.getString("id") + ")\">Edit</a>"
                                    + "" + "<a class=\"btn btn-danger btn-sm\" onClick=\"Delete(" + rs.getString("id") + ") \">Delete</a></td>\n"
                                    + "</td>\n"
                                    + "            </tr>\n");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "SoilTestingTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Farmer Name</th>\n"
                            + "                <th>Farm</th>\n"
                            + "                <th>Soil</th>\n"
                            + "                <th>WD Technique Applied</th>\n"
                            + "                <th>Improvement In Soil</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details </th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select st.id,fm.FarmerName as farmerName,fld.landid as farm,sm.soil as soilid,wdtechnique,soilimprovement,"
                            + "st.EnteredBy,st.EnteredDate,st.RevisedBy,st.RevisedDate from soiltesting st "
                            + " left join farmermaster fm on(fm.id=st.FarmerId) "
                            + " left join soilmaster sm on(sm.id=st.soilid) "
                            + " left join farmerlanddetails fld on (fld.id = st.farmid) order by id desc";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("farmerName") + "</td>\n"
                                    + "                <td>" + rs.getString("farm") + "</td>\n"
                                    + "                <td>" + rs.getString("soilid") + "</td>\n"
                                    + "                <td>" + rs.getString("wdtechnique") + "</td>\n"
                                    + "                <td>" + rs.getString("soilimprovement") + "</td>\n"
                                    + " <td>" + rs.getString("EnteredBy") + " <br>" + rs.getString("EnteredDate") + "</br></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><a class=\"btn btn-primary btn-sm\" onClick=\"getsoiltestingdataforedit(" + rs.getString("id") + ")\">Edit</a>"
                                    + "" + "<a class=\"btn btn-danger btn-sm\" onClick=\"Delete(" + rs.getString("id") + ") \">Delete</a></td>\n"
                                    + "</td>\n"
                                    + "            </tr>\n");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "StockTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Crop</th>\n"
                            + "                <th>Category</th>\n"
                            + "                <th>Procurement Qty</th>\n"
                            + "                <th>Sale Qty</th>\n"
                            + "                <th>Remaining Stock</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "Select crop,cgm.categoryname as categoryid,Sum(pro.qty) as procuredqty,saleqty,(Sum(pro.qty)-saleqty) as remainingstock from cropmaster cm "
                            + "Left join Cropgrades cg on (cm.id=cg.cropid) "
                            + "Left join planning p on (p.GradeId=cg.id) "
                            + "Left join categorymaster cgm on (cgm.id=cm.categoryid) "
                            + "Left join (select sum(ProcurementQty) as qty,PlanningId from procurement) pro on (p.id=pro.PlanningId) "
                            + "left join (select sum(qty) as saleqty,gradeId from saleentry group by gradeId)se on (se.gradeid=cg.id) group by cg.id order by cm.id desc";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("crop") + "</td>\n"
                                    + "                <td>" + rs.getString("categoryid") + "</td>\n");
                            if (rs.getString("procuredqty") == null || rs.getString("saleqty") == null || rs.getString("remainingstock") == null) {
                                out.print("<td>0</td>");
                                out.print("<td>0</td>");
                                out.print("<td>0</td>");
                            } else {
                                out.print("<td>" + rs.getString("procuredqty") + "</td>\n");
                                out.print("<td>" + rs.getString("saleqty") + "</td>\n");
                                 out.print("<td>" + rs.getString("remainingstock") + "</td>\n");
                            }
                            out.print(" </tr>\n");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "GetCategoryData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    sql = "select * from categorymaster where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("categoryName") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetCustomerData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from customermaster where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("Customer_Name") + " -- " + rs.getString("Address") + " -- "
                                    + "" + rs.getString("City") + " -- " + rs.getString("Pincode") + " -- "
                                    + rs.getString("State") + " -- " + rs.getString("GST_Code")
                                    + " -- " + rs.getString("GSTIN") + " -- " + rs.getString("PanNo") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetSetupData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from setup where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("CompanyName") + " -- " + rs.getString("MobileNo") + " -- " + "" + rs.getString("Email")
                                    + " -- " + rs.getString("State") + " -- " + rs.getString("GSTIN") + " -- " + rs.getString("PanNo")
                                    + " -- " + rs.getString("Address") + " -- " + rs.getString("Account_Name") + " -- " + rs.getString("Bank_Name")
                                    + " -- " + "" + rs.getString("Account_No") + " -- " + rs.getString("Branch_Name") + " -- "
                                    + rs.getString("IFSC_Code") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetRegionData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from regionmaster where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("Region") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetStateData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from statemaster where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("regionId") + " -- " + rs.getString("state") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetDistrictData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from districtmaster where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            String regionid = FindId("statemaster", "id", rs.getString("stateId"), "regionid");
                            out.print(rs.getString("stateId") + " -- " + rs.getString("district") + " -- " + regionid + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetTalukaData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from talukamaster where id=" + Id + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            String Stateid = FindId("districtmaster", "id", rs.getString("districtId"), "Stateid");
                            String regionid = FindId("statemaster", "id", Stateid, "regionid");
                            out.print(regionid + " -- " + Stateid + " -- " + rs.getString("districtId") + " -- " + rs.getString("Taluka") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetUomData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from uommaster where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("uom") + " -- " + rs.getString("type")
                                    + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetPlanningData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from planning where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("FarmerId") + " -- " + rs.getString("LandId") + " -- "
                                    + rs.getString("CropId") + " -- " + rs.getString("GradeId") + " -- "
                                    + rs.getString("TotalSeedsPlanted") + " -- " + rs.getString("PlantationArea") + ""
                                    + " -- " + rs.getString("PlanningDate") + " -- "
                                    + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                break;

                case "GetProcurementData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select p.id,fm.id as farmerid,fld.LandId as land,cid.crop as crop,cg.Grade as grade,PlanningId,ProcurementDate,ProcurementQTY,Rate,VehicleNo,StaffName,p.EnteredBy,p.EnteredDate,p.RevisedBy,p.RevisedDate from procurement p "
                            + "left join planning pl on (pl.id=p.PlanningId)"
                            + " left join farmermaster fm on(fm.id=pl.FarmerId) "
                            + "left join farmerlanddetails fld on(fld.id=pl.LandId)"
                            + " left join cropmaster cid on (cid.id = pl.CropId)"
                            + " left join cropgrades cg on (cg.id = pl.GradeId) where p.id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("farmerid") + " -- " + rs.getString("PlanningId") + " -- " + rs.getString("land") + " -- "
                                    + rs.getString("crop") + " -- " + rs.getString("grade") + " -- "
                                    + rs.getString("ProcurementDate") + " -- " + rs.getString("ProcurementQTY") + ""
                                    + " -- " + rs.getString("Rate") + " -- " + rs.getString("VehicleNo") + " -- " + rs.getString("StaffName") + " -- "
                                    + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetProcurementDataForPayment": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select p.id,fm.FarmerName AS farmerName,cid.crop as crop,cg.Grade as grade,ProcurementQTY,Rate from procurement p "
                            + "left join planning pl on (pl.id=p.PlanningId)"
                            + " left join farmermaster fm on(fm.id=pl.FarmerId) "
                            + " left join cropmaster cid on (cid.id = pl.CropId)"
                            + " left join cropgrades cg on (cg.id = pl.GradeId) where p.id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("farmerName") + " -- " + rs.getString("crop") + " -- " + rs.getString("grade") + " -- "
                                    + rs.getString("ProcurementQTY") + " -- " + rs.getString("Rate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetPaymentData": {
                    String id = request.getParameter("ID");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    sql = "select pay.id,fm.FarmerName as farmerName,cid.crop as crop,cg.Grade as grade,p.procurementQty as qty,Paymentdate,"
                            + "PayableAmount,paidAmount,Modeofpayment,pay.EnteredBy,pay.EnteredDate,pay.revisedby,"
                            + "pay.reviseddate from payment pay "
                            + "Left join procurement p on (p.id=pay.procurementid)"
                            + "left join planning pl on (pl.id=p.PlanningId)"
                            + " left join farmermaster fm on(fm.id=pl.FarmerId) "
                            + "left join cropmaster cid on (cid.id = pl.CropId) "
                            + "left join cropgrades cg on (cg.id = pl.GradeId) where pay.id= " + id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("farmerName") + " -- " + rs.getString("crop") + " -- " + rs.getString("grade") + " -- " + rs.getString("qty") + " -- "
                                    + rs.getString("PayableAmount") + " -- " + rs.getString("paidAmount") + " -- " + rs.getString("Paymentdate")
                                    + " -- " + rs.getString("Modeofpayment") + " -- " + rs.getString("RevisedBy") + " -- "
                                    + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetVisitData": {
                    String id = request.getParameter("id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from visitreport where id=" + id + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("VisitDate") + " -- " + rs.getString("VillageId") + " -- "
                                    + "" + rs.getString("NoOfMember") + " -- " + rs.getString("VillageInCharge") + " -- "
                                    + rs.getString("TrainingDetails") + " -- " + rs.getString("AddedFarmers")
                                    + " -- " + rs.getString("ConductedBy") + " -- " + rs.getString("ConductedDate") + " -- " + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetTestingData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    sql = "select * from soiltesting where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("farmerid") + " -- " + rs.getString("farmid") + " -- "
                                    + rs.getString("soilid") + " -- " + rs.getString("wdTechnique") + " -- "
                                    + rs.getString("soilimprovement") + " -- " + rs.getString("RevisedBy") + " -- "
                                    + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }

                break;

                case "regiontaluka": {

                    String regionid = request.getParameter("regionId");
                    String sql = "select * from regionmaster";
                    PrintWriter out = response.getWriter();

                    out.print("<select class=\"form-control\" type = \"text\" id = \"" + regionid + "\" onChange=\"getStateDatafortaluka(this.value)\"> \n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Region</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("Region") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;
                case "regiondistrict": {

                    String regionid = request.getParameter("regionId");
                    String sql = "select * from regionmaster";
                    PrintWriter out = response.getWriter();

                    out.print("<select class=\"form-control\" type = \"text\" id = \"" + regionid + "\" onChange=\"getStateDataDDL(this.value)\"> \n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Region</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("Region") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;
                case "stateddl": {
                    String regionid = request.getParameter("regionId");
                    String StateId = request.getParameter("Stateid");
                    String sql = "select * from statemaster where regionid=" + regionid + "";
                    PrintWriter out = response.getWriter();

                    out.print("<select class=\"form-control\" type = \"text\" name = \"stateId\" id = \"" + StateId + "\" onChange=\"getDistrictData(this.value)\"> \n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select State</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("State") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;

                case "districtddl": {
                    String Stateid = request.getParameter("Stateid");
                    String sql = "select * from districtmaster where Stateid=" + Stateid + "";
                    PrintWriter out = response.getWriter();

                    out.print("<select class=\"form-control\" type = \"text\" name = \"districtId\" id = \"districtId\"> \n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select District</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("district") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;

                case "categoryddl": {
                    String sql = "select * from categorymaster";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"categoryId\" id=\"categoryId\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Category</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("categoryName") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "regionddl": {
                    String sql = "select * from regionmaster";
                    PrintWriter out = response.getWriter();

                    out.print(" <select class=\"form-control\" type=\"text\" name=\"regionId\" id=\"regionId\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Region</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("Region") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "uomddl": {
                    String sql = "select * from uommaster";
                    PrintWriter out = response.getWriter();

                    out.print(" <select class=\"form-control\" type=\"text\" name=\"uomId\" id=\"uomId\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select UOM</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("uom") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "farmerddl": {
                    String sql = "select * from farmermaster";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"FarmerId\" id=\"FarmerId\" required onchange=\"getLandDataforPlanning(this.value)\">\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Farmer</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("FarmerName") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "landddl": {
                    String FarmerId = request.getParameter("FarmerId");
                    String sql = "select * from farmerlanddetails where FarmerId=" + FarmerId + "";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"LandId\" id=\"LandId\">\n");
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Land</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("LandId") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "cropddl": {
                    String sql = "select * from cropmaster";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"CropId\" id=\"CropId\" onchange=\"getGradeDataforPlanning(this.value)\">\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Crop</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("crop") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "gradeddl": {
                    String CropId = request.getParameter("CropId");
                    String sql = "select * from cropgrades where CropId=" + CropId + "";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"GradeId\" id=\"GradeId\">\n");
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Grade</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("Grade") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "planningddl": {
                    String farmerid = request.getParameter("farmerid");
                    String sql = "select * from planning where farmerid=" + farmerid + "";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"PlanningId\" id=\"PlanningId\" onchange=\"getFarmerDataForProcurement(this.value)\">\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Planning Id</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("id") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "getfarmerdatafromplanning": {
                    String Id = request.getParameter("PlanningId");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select p.id,fm.FarmerName as farmer,fld.LandId as land,cid.crop as crop,cg.Grade as grade,TotalSeedsPlanted,PlantationArea,PlanningDate,p.EnteredBy,p.EnteredDate,p.RevisedBy,p.RevisedDate from planning p "
                            + "left join farmermaster fm on (p.FarmerId=fm.id)"
                            + " left join farmerlanddetails fld on (p.LandId = fld.id)"
                            + " left join cropmaster cid on (p.CropId = cid.id)"
                            + " left join cropgrades cg on (p.GradeId = cg.id) where p.id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("farmer") + " -- " + rs.getString("land") + " -- "
                                    + rs.getString("crop") + " -- " + rs.getString("grade"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "farmerddlforProcurement": {
                    String sql = "select * from farmermaster";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"farmerName\" id=\"farmerName\" onchange=\"getPlanningDataforProcurement(this.value)\">\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Farmer</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("FarmerName") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "staffddl": {
                    String sql = "select * from usermaster";
                    PrintWriter out = response.getWriter();

                    out.print(" <select class=\"form-control\" type=\"text\" name=\"StaffName\" id=\"StaffName\">\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Staff Name</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("UserId") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "conductedbyddl": {
                    String sql = "select * from usermaster";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"conductedby\" id=\"conductedby\" required\">\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Conducted By</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("UserId") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "villageddl": {
                    String sql = "select * from villagemaster";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"VillageId\" id=\"VillageId\" required\">\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Village</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("Village") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "soilfarmerddl": {
                    String sql = "select * from farmermaster";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"farmerName\" id=\"farmerName\"  onchange=\"getLandDataforSoilTesting(this.value)\">\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Farmer</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("FarmerName") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "soillandddl": {
                    String FarmerId = request.getParameter("Farmerid");
                    String sql = "select * from farmerlanddetails where FarmerId=" + FarmerId + "";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"farmid\" id=\"farmid\">\n");
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Land</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("LandId") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "soilddl": {
                    String sql = "select * from soilmaster";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"soilid\" id=\"soilid\">\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Soil Type</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("Soil") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "checkCategoryDelete": {
                    String categoryId = request.getParameter("categoryId");
                    String sql = "";
                    int i = 0;
                    PrintWriter out = response.getWriter();
                    String tablename = "cropmaster";
                    sql = "select * from " + tablename + " where CategoryId = " + categoryId + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        while (rs.next()) {
                            i++;
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    out.print(i);
                }
                break;

                case "checkPlanningDelete": {
                    String planningId = request.getParameter("planningId");
                    String sql = "";
                    int i = 0;
                    PrintWriter out = response.getWriter();
                    String tablename = "procurement";
                    sql = "select * from " + tablename + " where PlanningId = " + planningId + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        while (rs.next()) {
                            i++;
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    out.print(i);
                }
                break;

                case "checkRegionDelete": {
                    String regionId = request.getParameter("regionId");
                    String sql = "";
                    int i = 0;
                    PrintWriter out = response.getWriter();
                    String tablename = "statemaster";
                    sql = "select * from " + tablename + " where RegionId = " + regionId + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        while (rs.next()) {
                            i++;
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    out.print(i);
                }
                break;

                case "checkStateDelete": {
                    String stateId = request.getParameter("stateId");
                    String sql = "";
                    int i = 0;
                    PrintWriter out = response.getWriter();
                    String tablename = "districtmaster";
                    sql = "select * from " + tablename + " where StateId = " + stateId + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        while (rs.next()) {
                            i++;
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    out.print(i);
                }
                break;

                case "checkDistrictDelete": {
                    String districtId = request.getParameter("districtId");
                    String sql = "";
                    int i = 0;
                    PrintWriter out = response.getWriter();
                    String tablename = "talukamaster";
                    sql = "select * from " + tablename + " where DistrictId = " + districtId + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        while (rs.next()) {
                            i++;
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    out.print(i);
                }
                break;

                case "checkTalukaDelete": {
                    String talukaId = request.getParameter("talukaId");
                    String sql = "";
                    int i = 0;
                    PrintWriter out = response.getWriter();
                    String tablename = "villagemaster";
                    sql = "select * from " + tablename + " where TalukaId = " + talukaId + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        while (rs.next()) {
                            i++;
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                        Logger.getLogger(Agrimgmt.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    out.print(i);
                }
                break;
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (null != action) {
            switch (action) {
                case "saveCategory": {
                    String categoryName = request.getParameter("categoryName");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into categorymaster (categoryName,EnteredDate,EnteredBy) values('" + categoryName + "','" + EnteredDate + "','" + user + "')";
                    } else {
                        sql = "update categorymaster set categoryName='" + categoryName + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                    break;
                }

                case "saveCustomer": {
                    String cname = request.getParameter("cname");
                    String address = request.getParameter("address");
                    String city = request.getParameter("city");
                    String pincode = request.getParameter("pincode");
                    String state = request.getParameter("state");
                    String gstCode = request.getParameter("gstCode");
                    String gstin = request.getParameter("gstin");
                    String PanNo = request.getParameter("PanNo");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into customermaster (Customer_Name,Address,City,State,Pincode,GST_Code,GSTIN,PanNo,EnteredBy,EnteredDate,Close)"
                                + " values('" + cname + "','" + address + "','" + city + "','" + state + "','" + pincode + "','" + gstCode + "','" + gstin + "','" + PanNo + "','" + user + "','" + EnteredDate + "','1')";

                    } else {
                        sql = "update customermaster set Customer_Name='" + cname + "',Address='" + address + "',City='" + city + "',State='" + state + "',Pincode='" + pincode + "',GST_Code='" + gstCode + "',GSTIN='"
                                + gstin + "',PanNo='" + PanNo + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveSetup": {
                    String CompanyName = request.getParameter("CompanyName");
                    String MobileNo = request.getParameter("MobileNo");
                    String Email = request.getParameter("Email");
                    String State = request.getParameter("State");
                    String GSTIN = request.getParameter("GSTIN");
                    String PanNo = request.getParameter("PanNo");
                    String Address = request.getParameter("Address");
                    String acname = request.getParameter("acname");
                    String bankname = request.getParameter("bankname");
                    String bname = request.getParameter("bname");
                    String acnumber = request.getParameter("acnumber");
                    String ifsc = request.getParameter("ifsc");
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if (checkCompanySetup()) {
                        sql = "update setup set CompanyName='" + CompanyName + "',MobileNo='" + MobileNo + "',Email='" + Email + "',State='" + State + "',"
                                + "GSTIN='" + GSTIN + "',PanNo='" + PanNo + "'," + "Address='" + Address + "',Account_Name='" + acname + "',Bank_Name='" + bankname + "',"
                                + "Branch_Name='" + bname + "',Account_No='" + acnumber + "',IFSC_Code='" + ifsc + "' where Id='1'";

                    } else {
                        sql = "insert into setup(CompanyName,MobileNo,Email,State,GSTIN,PanNo,Address,Account_Name,Bank_Name,Branch_Name,Account_No,"
                                + "IFSC_Code) values('" + CompanyName + "','" + MobileNo + "','" + Email + "','" + State + "','" + GSTIN + "','" + PanNo
                                + "','" + Address + "','" + acname + "','" + bankname + "','" + bname + "','" + acnumber + "','" + ifsc + "')";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("1".equals(Id)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveRegion": {
                    String Region = request.getParameter("Region");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    String Id = request.getParameter("Id");

                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(Id)) {
                        sql = "insert into regionmaster "
                                + "(Region,EnteredDate,EnteredBy,Close) "
                                + "values('" + Region + "','" + EnteredDate + "','" + user + "','1')";

                    } else {
                        sql = "update regionmaster set Region='" + Region + "' where id=" + Id + "";

                    }
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(Id)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveState": {
                    String regionId = request.getParameter("regionId");
                    String state = request.getParameter("state");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(Id)) {
                        sql = "insert into statemaster "
                                + "(regionId,state,EnteredDate,EnteredBy,Close) "
                                + "values(" + regionId + ",'" + state + "','" + EnteredDate + "','" + user + "','1')";

                    } else {
                        sql = "update statemaster set regionId=" + regionId + ",state='" + state + "' where id=" + Id + "";

                    }
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(Id)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }

                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveDistrict": {
                    String stateId = request.getParameter("stateId");
                    String district = request.getParameter("district");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(Id)) {
                        sql = "insert into districtmaster "
                                + "(stateId,district,EnteredDate,EnteredBy,Close) "
                                + "values(" + stateId + ",'" + district + "','" + EnteredDate + "','" + user + "','1')";

                    } else {
                        sql = "update districtmaster set stateId=" + stateId + ",district='" + district + "' where id=" + Id + "";

                    }
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(Id)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }

                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveTaluka": {
                    String districtId = request.getParameter("districtId");
                    String Taluka = request.getParameter("Taluka");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(Id)) {
                        sql = "insert into talukamaster "
                                + "(districtId,Taluka,EnteredDate,EnteredBy,Close) "
                                + "values('" + districtId + "','" + Taluka + "','" + EnteredDate + "','" + user + "','1')";

                    } else {
                        sql = "update talukamaster set districtId='" + districtId + "',Taluka='" + Taluka + "' where id=" + Id + "";

                    }
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(Id)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveUOM": {
                    String UOM = request.getParameter("UOM");
                    String type = request.getParameter("type");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into uommaster(UOM,type,EnteredDate,EnteredBy) values('" + UOM + "','" + type + "','" + EnteredDate + "','" + user + "')";

                    } else {
                        sql = "update uommaster set UOM='" + UOM + "',type='" + type + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if ("0".equals(ID)) {
                            out.print("successfully Saved");
                        } else {
                            out.print("successfully Updated");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "savePlanning": {
                    String FarmerId = request.getParameter("FarmerId");
                    String LandId = request.getParameter("LandId");
                    String CropId = request.getParameter("CropId");
                    String GradeId = request.getParameter("GradeId");
                    String TotalSeedsPlanted = request.getParameter("TotalSeedsPlanted");
                    String PlantationArea = request.getParameter("PlantationArea");
                    String PlanningDate = request.getParameter("PlanningDate");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into planning (FarmerId,LandId,CropId,GradeId,TotalSeedsPlanted,PlantationArea,PlanningDate,EnteredBy,EnteredDate,Close) "
                                + "values('" + FarmerId + "','" + LandId + "','" + CropId + "','" + GradeId + "','" + TotalSeedsPlanted + "','" + PlantationArea + "','" + PlanningDate + "','" + user + "','" + EnteredDate + "','" + '0' + "')";
                    } else {
                        sql = "update planning set FarmerId='" + FarmerId + "',LandId='" + LandId + "',CropId='" + CropId + "',GradeId='" + GradeId + "',TotalSeedsPlanted='" + TotalSeedsPlanted + "',PlantationArea='" + PlantationArea + "',PlanningDate='" + PlanningDate + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if ("0".equals(ID) && success > 0) {
                            out.print("successfully Saved");
                        } else {
                            out.print("successfully Updated");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveProcurement": {
                    String PlanningId = request.getParameter("PlanningId");
                    String ProcurementDate = request.getParameter("ProcurementDate");
                    String ProcurementQTY = request.getParameter("ProcurementQTY");
                    String Rate = request.getParameter("Rate");
                    String VehicleNo = request.getParameter("VehicleNo");
                    String StaffName = request.getParameter("StaffName");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into procurement (PlanningId,ProcurementDate,ProcurementQTY,Rate,VehicleNo,StaffName,EnteredBy,EnteredDate) "
                                + "values('" + PlanningId + "','" + ProcurementDate + "','" + ProcurementQTY + "','" + Rate + "','" + VehicleNo + "','" + StaffName + "','" + user + "','" + EnteredDate + "')";
                    } else {
                        sql = "update procurement set PlanningId='" + PlanningId + "',ProcurementDate='" + ProcurementDate + "',ProcurementQTY='" + ProcurementQTY + "',Rate='" + Rate + "',VehicleNo='" + VehicleNo + "',StaffName='" + StaffName + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if ("0".equals(ID) && success > 0) {
                            out.print("successfully Saved");
                        } else {
                            out.print("successfully Updated");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "savePayment": {
                    String ProcurementId = request.getParameter("ProcurementId");
                    String Rate = request.getParameter("Rate");
                    String PaidAmount = request.getParameter("PaidAmount");
                    String PaymentDate = request.getParameter("PaymentDate");
                    String ModeOfPayment = request.getParameter("ModeOfPayment");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();

                    if ("0".equals(ID)) {
                        sql = "insert into payment (ProcurementId,PayableAmount,PaidAmount,PaymentDate,ModeOfPayment,EnteredBy,EnteredDate) "
                                + "values(" + ProcurementId + "," + Rate + "," + PaidAmount + ",'" + PaymentDate + "','" + ModeOfPayment + "','" + user + "','" + EnteredDate + "')";
                    } else {
                        sql = "update payment set PayableAmount=" + Rate + ",PaidAmount=" + PaidAmount + ",PaymentDate='" + PaymentDate + "',ModeOfPayment='" + ModeOfPayment + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";
                    }

                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if (("0".equals(ID))) {
                                sql = "update Procurement set close='1' where Id=" + ProcurementId + "";
                                ps = con.prepareStatement(sql);
                                success = ps.executeUpdate();
                                if (success > 0) {
                                    out.print("Successfully Saved");
                                }
                            } else {
                                out.print("Successfully Updated");
                            }

                        } else {
                            out.print("Not Saved");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveVisitReport": {
                    String visitdate = request.getParameter("visitdate");
                    String VillageId = request.getParameter("VillageId");
                    String noofmembers = request.getParameter("noofmembers");
                    String villageincharge = request.getParameter("villageincharge");
                    String trainingdetails = request.getParameter("trainingdetails");
                    String addedfarmers = request.getParameter("addedfarmers");
                    String conductedby = request.getParameter("conductedby");
                    String conducteddate = request.getParameter("conducteddate");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into visitreport (VisitDate,VillageId,NoOfMember,VillageInCharge,AddedFarmers,ConductedBy,ConductedDate,TrainingDetails,EnteredBy,EnteredDate)"
                                + " values('" + visitdate + "','" + VillageId + "','" + noofmembers + "','" + villageincharge + "','" + addedfarmers + "','" + conductedby + "','" + conducteddate + "','" + trainingdetails + "','" + user + "','" + EnteredDate + "')";

                    } else {
                        sql = "update visitreport set VisitDate='" + visitdate + "',VillageId='" + VillageId + "',NoOfMember='" + noofmembers + "',VillageInCharge='" + villageincharge + "',AddedFarmers='" + addedfarmers + "',"
                                + "ConductedBy='" + conductedby + "',ConductedDate='" + conducteddate + "',TrainingDetails='" + trainingdetails + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "SaveSoilTesting": {
                    String farmerName = request.getParameter("FarmerName");
                    String land = request.getParameter("Farm");
                    String soil = request.getParameter("Soil");
                    String wdtechnique = request.getParameter("WdTechnique");
                    String improvement = request.getParameter("SoilImp");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into soiltesting (FarmerId,FarmId,SoilId,wdTechnique,SoilImprovement,EnteredBy,EnteredDate)"
                                + " values('" + farmerName + "','" + land + "','" + soil + "','" + wdtechnique + "','" + improvement + "','" + user + "','" + EnteredDate + "')";

                    } else {
                        sql = "update soiltesting set FarmerId='" + farmerName + "',FarmId='" + land + "',SoilId='" + soil + "',wdTechnique='" + wdtechnique + "',"
                                + "SoilImprovement='" + improvement + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "Delete": {

                    String table = request.getParameter("tbl");

                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    sql = "Delete from " + table + " where id=" + ID + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            out.print("Data deleted Successfully");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;
                default:
                    break;
            }
        }
    }

    private boolean checkCompanySetup() {
        String sql = "";

        sql = "select * from setup where Id=1";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                return true;

            }

        } catch (SQLException ex) {
            Logger.getLogger(Agrimgmt.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    private String FindId(String tbl, String conditionparameter, String parametervalue, String valueid) {
        String sql = "";
        String value = "";
        sql = "select distinct " + valueid + " from " + tbl + " where " + conditionparameter + "=" + parametervalue + "";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                value = rs.getString(1);
                return value;

            }

        } catch (SQLException ex) {
            Logger.getLogger(Agrimgmt.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return value;
    }
}
