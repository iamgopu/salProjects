package News;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet(name = "imgUpload", urlPatterns = {"/imgUpload"})
@MultipartConfig
public class imgUpload extends HttpServlet {

    Connection con = dbConnection.getCon();
    java.util.Date curDate = new java.util.Date();
String Username="";
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Statement stmt = null;
        String sql = null;
        BufferedInputStream bin = null;
        BufferedOutputStream bout = null;
        InputStream in = null;
        int ID = Integer.parseInt(request.getParameter("ID"));
        String Type = request.getParameter("Type");
        if (null != Type) {
            switch (Type) {
                case "Images":
                    response.setContentType("image/jpeg");
                    break;
                case "Video":
                    response.setContentType("video/mp4");
                    break;
                case "Document":
                    response.setContentType("application/pdf");
                    break;
                default:
                    break;
            }
        }
        response.setContentType("image/jpeg");
        ServletOutputStream out;
        out = response.getOutputStream();

        try {
            stmt = con.createStatement();
            sql = "SELECT file FROM uploadtbl WHERE NewsId=" + ID + "";
            ResultSet result = stmt.executeQuery(sql);
            if (result.next()) {
                in = result.getBinaryStream("file");//Since my data was in third column of table.

            }
            bin = new BufferedInputStream(in);
            bout = new BufferedOutputStream(out);
            int ch = 0;
            while ((ch = bin.read()) != -1) {
                bout.write(ch);
            }
        } catch (SQLException ex) {
            Logger.getLogger(imgUpload.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (bin != null) {
                    bin.close();
                }
                if (in != null) {
                    in.close();
                }
                if (bout != null) {
                    bout.close();
                }
                if (out != null) {
                    out.close();
                }

            } catch (IOException ex) {
                System.out.println("Error : " + ex.getMessage());
            }
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Part Filepart = request.getPart("file");
        String News_Type = request.getParameter("News_Type");
        String News_Name = request.getParameter("News_Name");
        String News_Category = request.getParameter("News_Category");
        String News_Description = request.getParameter("News_Description");
        String News_Region = request.getParameter("News_Region");
        String News_Priority = request.getParameter("News_Priority");
        String Status = request.getParameter("Status");
        Username = request.getParameter("user");
        java.sql.Timestamp Entered_Date = new java.sql.Timestamp(curDate.getTime());
        java.sql.Timestamp Revised_Date = new java.sql.Timestamp(curDate.getTime());
        String ID = request.getParameter("Id");
        String result = "";
        String sql = "";

        PrintWriter out = response.getWriter();
        if ("0".equals(ID)) {
            sql = "insert into news_manager (News_Type,News_Name,News_Category,News_Description,News_Region,News_Priority,Status,Entered_By,Entered_Date) values('" + News_Type + "','" + News_Name + "','" + News_Category + "','" + News_Description + "','" + News_Region + "','" + News_Priority + "','" + Status + "','" + Username + "','" + Entered_Date + "')";
        } else {
            sql = "update news_manager set News_Type='" + News_Type + "',News_Name='" + News_Name + "',News_Category='" + News_Category + "',News_Description='" + News_Description + "',News_Region='" + News_Region + "',News_Priority='" + News_Priority + "',Status='" + Status + "',Revised_Date='" + Revised_Date + "' where id=" + ID + "";

        }

        try {

            PreparedStatement ps = con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            int success = ps.executeUpdate();
            if (success > 0) {
                
                if ("0".equals(ID)) {
                    ResultSet rs = ps.getGeneratedKeys();
                    if (rs.next()){
    int risultato=rs.getInt(1);

                    result = saveImage(String.valueOf(risultato), Filepart,"insert");
                    }
                } else {
                    if(Filepart==null){
                       result="Successfully updated";
                    }else{
                        result = saveImage(ID, Filepart,"update");
                    }
                    
                }
                out.print(result);
            }
        } catch (SQLException ex) {
            out.print(ex);
        }

    }

    private String saveImage(String Id, Part file,String action) {

        String result = "";
        InputStream inputStream = null;
        try {
            inputStream = file.getInputStream();
            java.sql.Timestamp UploadedDate = new java.sql.Timestamp(curDate.getTime());
            String sql = "";
            if ("insert".equals(action)) {
                sql = "INSERT INTO uploadtbl (NewsId,file,UploadedBy,UploadedDate) values (" + Id + ",?,'"+Username+"','" + UploadedDate + "')";
            } else {
                sql = "update uploadtbl set file=?,UploadedBy='user',UploadedDate='" + UploadedDate + "' where newsId=" + Id + "";
            }

            PreparedStatement statement = null;
            statement = con.prepareStatement(sql);

            statement.setBlob(1, inputStream);

            int success = statement.executeUpdate();
            if (success > 0) {
             if("insert".equals(action)){
                 result = "Successfully Inserted";
             }else{
                 result = "Successfully Updated"; 
             }
                
            } else {
                result = "Image is not Inserted properly please check";
            }

        } catch (SQLException | IOException ex) {
            Logger.getLogger(imgUpload.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }

            } catch (IOException ex) {
                System.out.println("Error : " + ex.getMessage());
            }
        }
        return result;
    }

}
