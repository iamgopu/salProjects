package News;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class newsServlet extends HttpServlet {

    Connection con = dbConnection.getCon();
    java.util.Date curDate = new java.util.Date();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (null != action) {
            switch (action) {
                case "categoryTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr No.</th>\n"
                            + "                <th>Category Name</th>\n"
                            + "                <th>Category Description</th>\n"
                            + "                <th>Status</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from category_master";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("Category_Name") + "</td>\n"
                                    + "                <td>" + rs.getString("Category_Description") + "</td>\n"
                                    + "                <td>" + rs.getString("Status") + "</td>\n"
                                    + "                <td>" + rs.getString("Entered_By") + " <br>" + rs.getString("Entered_Date") + "</br></td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" onClick=\"getdataforedit(" + rs.getString("id") + ")\">Edit</a>&nbsp"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"Delete(" + rs.getString("id") + ",'" + rs.getString("Category_Name") + "') \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;
                case "AreaTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr No.</th>\n"
                            + "                <th>Area Name</th>\n"
                            + "                <th>Area Description</th>\n"
                            + "                <th>Status</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from area_manager";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("Area_Name") + "</td>\n"
                                    + "                <td>" + rs.getString("Area_Description") + "</td>\n"
                                    + "                <td>" + rs.getString("Status") + "</td>\n"
                                    + "                <td>" + rs.getString("Entered_By") + " <br>" + rs.getString("Entered_Date") + "</br></td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" onClick=\"getdataforedit(" + rs.getString("id") + ")\">Edit</a>&nbsp"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"Delete(" + rs.getString("id") + ",'" + rs.getString("Area_Name") + "') \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;
                case "SubscriberTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr No.</th>\n"
                            + "                <th>Subscriber Name</th>\n"
                            + "                <th>Subscriber Email</th>\n"
                            + "                <th>Subscriber Mobile</th>\n"
                            + "                <th>Subscriber Area</th>\n"
                            + "                <th>Subscription Date</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from subscriber_manager";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("Subscriber_Name") + "</td>\n"
                                    + "                <td>" + rs.getString("Subscriber_Email") + "</td>\n"
                                    + "                <td>" + rs.getString("Subscriber_Mob") + "</td>\n"
                                    + "                <td>" + rs.getString("Subscriber_Area") + "</td>\n"
                                    + "                <td>" + rs.getString("Entered_Date") + "</td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" onClick=\"getdataforedit(" + rs.getString("id") + ")\">Edit</a>&nbsp"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"Delete(" + rs.getString("id") + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;
                case "NewsTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr No.</th>\n"
                            + "                <th>News Type</th>\n"
                            + "                <th>News Name</th>\n"
                            + "                <th>News Category</th>\n"
                            + "                <th>News Description</th>\n"
                            + "                <th>News Region</th>\n"
                            + "                <th>News Priority</th>\n"
                            + "                <th>News Status</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Date</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from news_manager";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("News_Type") + "</td>\n"
                                    + "                <td>" + rs.getString("News_Name") + "</td>\n"
                                    + "                <td>" + rs.getString("News_Category") + "</td>\n"
                                    + "                <td>" + rs.getString("News_Description") + "</td>\n"
                                    + "                <td>" + rs.getString("News_Region") + "</td>\n"
                                    + "                <td>" + rs.getString("News_Priority") + "</td>\n"
                                    + "                <td>" + rs.getString("Status") + "</td>\n"
                                    + "                <td>" + rs.getString("Entered_By") + " <br>" + rs.getString("Entered_Date") + "</br></td>\n");
                            if (rs.getString("revised_date") == null) {
                                out.print("<td>Not Revised</td>");
                            } else {
                                out.print("<td>" + rs.getString("revised_date") + "</td>");
                            }
                            out.print("                <td><a class=\"btn btn-primary btn-sm\" onClick=\"getdataforedit(" + rs.getString("id") + ")\">Edit</a>"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"Delete(" + rs.getString("id") + ",'" + rs.getString("News_Category") + "','" + rs.getString("News_Region") + "') \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;
                case "userTable": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr No.</th>\n"
                            + "                <th>username</th>\n"
                            + "                <th>Mobile Number</th>\n"
                            + "                <th>Email</th>\n"
                            + "                <th>Role</th>\n"
                            + "                <th>Department</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from usermaster";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("username") + "</td>\n"
                                    + "                <td>" + rs.getString("phone_No") + "</td>\n"
                                    + "                <td>" + rs.getString("mail_Id") + "</td>\n"
                                    + "                <td>" + rs.getString("role") + "</td>\n"
                                    + "                <td>" + rs.getString("department") + "</td>\n"
                                    + "                <td>" + rs.getString("Entered_By") + " <br/>" + rs.getString("Entered_Date") + "<br/></td>\n"
                                    + "                <td><a class=\"btn btn-primary btn-sm\" onClick=\"getdataforedit(" + rs.getString("id") + ")\">Edit</a>&nbsp"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"Delete(" + rs.getString("id") + ",'" + rs.getString("username") + "') \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + "        ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;
                case "GetCategoryData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from category_master where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("Category_Name") + " -- " + rs.getString("Category_Description") + " -- "
                                    + "" + rs.getString("Status") + " -- " + rs.getString("Revised_Date") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetAreaData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from area_manager where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("Area_Name") + " -- " + rs.getString("Area_Description") + " -- "
                                    + "" + rs.getString("Status") + " -- " + rs.getString("Revised_Date") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetSubscriberData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from subscriber_manager where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("Subscriber_Name") + " -- " + rs.getString("Subscriber_Email") + " -- "
                                    + "" + rs.getString("Subscriber_Mob") + " -- " + "" + rs.getString("Subscriber_Area")
                                    + " -- " + rs.getString("Revised_Date") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetNewsData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from news_manager where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        while (rs.next()) {

                            out.print(rs.getString("News_Type") + " -- " + rs.getString("News_Name") + " -- " + rs.getString("News_Category") + " -- "
                                    + "" + rs.getString("News_Description") + " -- " + rs.getString("News_Region") + " -- " + rs.getString("News_Priority")
                                    + " -- " + rs.getString("Status") + " -- " + rs.getString("Revised_Date") + " -- " + rs.getString("Id")+ " -- " + rs.getString("completed"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;
                case "GetUserData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from usermaster where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("username") + " -- " + rs.getString("phone_No") + " -- "
                                    + "" + rs.getString("mail_Id") + " -- " + "" + rs.getString("password") + " -- " + "" + rs.getString("role") + " -- " + "" + rs.getString("department") + " -- "
                                    + rs.getString("Revised_Date") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;
                case "GetCompanyData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    sql = "select * from company_details where Id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        while (rs.next()) {

                            out.print(rs.getString("Company_name") + " -- " + rs.getString("News_Channel") + " -- " + ""
                                    + rs.getString("Company_address") + " -- " + "" + rs.getString("phoneNo") + " -- " + "" + rs.getString("Email_id") + " -- " + rs.getString("Revised_Date")+ " -- " + rs.getString("Id"));

                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;
                case "GetProfileData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from usermaster where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("username") + " -- " + rs.getString("phone_No") + " -- "
                                    + "" + rs.getString("mail_Id") + " -- " + "" + rs.getString("password") + " -- " + "" + rs.getString("role") + " -- " + "" + rs.getString("department") + " -- "
                                    + rs.getString("Revised_Date") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;
                case "Login": {
                    PrintWriter out = response.getWriter();
                    String mail_Id = request.getParameter("mail_Id");
                    String password = request.getParameter("password");
                    try {

                        PreparedStatement ps = con.prepareStatement("Select mail_Id,password,username,id,role from usermaster where mail_Id=? and password=? ");

                        ps.setString(1, mail_Id);
                        ps.setString(2, password);
                        ResultSet rs = ps.executeQuery();
                        if (rs.next()) {
                            out.print("Logged in Successfully -- " + rs.getString("username") + " -- " + rs.getString("ID") + " -- " + rs.getString("role"));
                            rs.close();
                        } else {
                            out.print("Check your username and password");
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "categoryddl": {
                    String sql = "select * from category_master";
                    PrintWriter out = response.getWriter();

                    out.print(" <select class=\"form-control\" type=\"text\" name=\"News_Category\" autocomplete=\"off\" id=\"News_Category\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option>Select Category</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option>" + rs.getString("Category_Name") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;
                case "Deletecheck": {
                    String user = request.getParameter("user");
                    String parameter = request.getParameter("parameter");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    int nooftable = 5;
                    int tblid = 0;
                    String tablename = "";
                    int i = 0;
                    for (tblid = 1; tblid < nooftable; tblid++) {
                        switch (tblid) {
                            case 1:
                                tablename = "area_manager";
                                break;
                            case 2:
                                tablename = "category_master";
                                break;
                            case 3:
                                tablename = "Company_details";
                                break;
                            case 4:
                                tablename = "news_manager";
                                break;

                            case 5:
                                tablename = "usermaster";
                                break;
                            default:
                                break;
                        }
                        sql = "select * from " + tablename + " where " + parameter + "='" + user + "'";

                        try {
                            PreparedStatement ps = con.prepareStatement(sql);
                            ResultSet rs = ps.executeQuery();

                            while (rs.next()) {
                                i++;
                            }

                        } catch (SQLException ex) {
                            out.print(ex);
                            Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    out.print(i);
                }
                break;
                case "checkCategoryDelete": {
                    String Category_Name = request.getParameter("categoryName");
                    String sql = "";
                           int i = 0;
                    PrintWriter out = response.getWriter();
                    String tablename = "news_manager";
                    sql = "select * from " + tablename + " where News_Category = '" + Category_Name + "'";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                         while (rs.next()) {
                                i++;
                            }
                    } catch (SQLException ex) {
                        out.print(ex);
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    out.print(i);
                }
                break;
                case "checkAreaDelete": {
                    String Area_Name = request.getParameter("Area_Name");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                           int i = 0;
                    String tablename = "news_manager";
                    sql = "select * from " + tablename + " where News_Region = '" + Area_Name + "'";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                         while (rs.next()) {
                                i++;
                            }
                    } catch (SQLException ex) {
                        out.print(ex);
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    out.print(i);
                }
                break;
                case "regionddl": {
                    String sql = "select * from area_manager";
                    PrintWriter out = response.getWriter();

                    out.print(" <select class=\"form-control\" type=\"text\" name=\"News_Region\" autocomplete=\"off\" id=\"News_Region\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option>Select Region</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option>" + rs.getString("Area_Name") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }

            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (null != action) {
            switch (action) {
                case "saveCategory": {
                    String Category_Name = request.getParameter("categoryName");
                    String Category_Description = request.getParameter("description");
                    String status = request.getParameter("status");
                    String user = request.getParameter("user");
                    java.sql.Timestamp enteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp Revised_Date = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into category_master (Category_Name,Category_Description,Status,Entered_Date,Entered_By) values('" + Category_Name + "','" + Category_Description + "','" + status + "','" + enteredDate + "','" + user + "')";
                    } else {
                        sql = "update category_master set Category_Name='" + Category_Name + "',Category_Description='" + Category_Description + "',status='" + status + "',Revised_Date='" + Revised_Date + "' where id=" + ID + "";

                    }

                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (("0".equals(ID)) && success > 0) {
                            out.print("Data Inserted");
                        } else {
                            out.print("Data Updated Successfully and you are redirecting to Category_Master");
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;
                case "saveArea": {
                    String Area_Name = request.getParameter("Area_Name");
                    String Area_Description = request.getParameter("Area_Description");
                    String Status = request.getParameter("Status");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp Revised_Date = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into area_manager (Area_Name,Area_Description,Status,Entered_Date,Entered_By) values('" + Area_Name + "','" + Area_Description + "','" + Status + "','" + EnteredDate + "','" + user + "')";
                    } else {
                        sql = "update area_manager set Area_Name='" + Area_Name + "',Area_Description='" + Area_Description + "',Status='" + Status + "',Revised_Date='" + Revised_Date + "' where id=" + ID + "";

                    }

                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (("0".equals(ID)) && success > 0) {
                            out.print("Data Inserted");
                        } else {
                            out.print("Data Updated Successfully and you are redirecting to Area_Master");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "saveSubscriber": {
                    String Subscriber_Name = request.getParameter("Subscriber_Name");
                    String Subscriber_Email = request.getParameter("Subscriber_Email");
                    String Subscriber_Mob = request.getParameter("Subscriber_Mob");
                    String Subscriber_Area = request.getParameter("Subscriber_Area");
                    java.sql.Timestamp Entered_Date = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp Revised_Date = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into subscriber_manager (Subscriber_Name,Subscriber_Email,Subscriber_Mob,Subscriber_Area,Entered_Date) values('" + Subscriber_Name + "','" + Subscriber_Email + "','" + Subscriber_Mob + "','" + Subscriber_Area + "','" + Entered_Date + "')";
                    } else {
                        sql = "update subscriber_manager set Subscriber_Name='" + Subscriber_Name + "',Subscriber_Email='" + Subscriber_Email + "',Subscriber_Mob='" + Subscriber_Mob + "',Subscriber_Area='" + Subscriber_Area + "',Revised_Date='" + Revised_Date + "' where id=" + ID + "";

                    }

                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (("0".equals(ID)) && success > 0) {
                            out.print("Data Inserted");
                        } else {
                            out.print("Data Updated Successfully and you are redirecting to Subscriber_Master");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;
                case "saveNews": {
                    String News_Type = request.getParameter("News_Type");
                    String News_Name = request.getParameter("News_Name");
                    String News_Category = request.getParameter("News_Category");
                    String News_Description = request.getParameter("News_Description");
                    String News_Region = request.getParameter("News_Region");
                    String News_Priority = request.getParameter("News_Priority");
                    String Status = request.getParameter("Status");
                    String user = request.getParameter("user");
                    java.sql.Timestamp Entered_Date = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp Revised_Date = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into news_manager (News_Type,News_Name,News_Category,News_Description,News_Region,News_Priority,Status,Entered_By,Entered_Date,Completed) values('" + News_Type + "','" + News_Name + "','" + News_Category + "','" + News_Description + "','" + News_Region + "','" + News_Priority + "','" + Status + "','" + user + "','" + Entered_Date + "','"+'1'+"')";
                    } else {
                        sql = "update news_manager set News_Type='" + News_Type + "',News_Name='" + News_Name + "',News_Category='" + News_Category + "',News_Description='" + News_Description + "',News_Region='" + News_Region + "',News_Priority='" + News_Priority + "',Status='" + Status + "',Revised_Date='" + Revised_Date + "' where id=" + ID + "";

                    }

                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (("0".equals(ID)) && success > 0) {
                            out.print("Data Inserted");
                        } else {
                            out.print("Data Updated Successfully and you are redirecting to News_Manager");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }
                
                case "Complete": {
                    String News_Type = request.getParameter("News_Type");
                    String News_Name = request.getParameter("News_Name");
                    String News_Category = request.getParameter("News_Category");
                    String News_Description = request.getParameter("News_Description");
                    String News_Region = request.getParameter("News_Region");
                    String News_Priority = request.getParameter("News_Priority");
                    String Status = request.getParameter("Status");
                    java.sql.Timestamp Entered_Date = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp Revised_Date = new java.sql.Timestamp(curDate.getTime());
                    String newsId = request.getParameter("newsId");

                    String sql = "";

                    PrintWriter out = response.getWriter();
                     if ("0".equals(newsId)) {
                        sql = "insert into news_manager (News_Type,News_Name,News_Category,News_Description,News_Region,News_Priority,Status,Entered_By,Entered_Date,Completed) values('" + News_Type + "','" + News_Name + "','" + News_Category + "','" + News_Description + "','" + News_Region + "','" + News_Priority + "','" + Status + "','" + Entered_Date + "','"+1+"')";
                    } else {
                        sql = "update news_manager set News_Type='" + News_Type + "',News_Name='" + News_Name + "',News_Category='" + News_Category + "',News_Description='" + News_Description + "',News_Region='" + News_Region + "',News_Priority='" + News_Priority + "',Status='" + Status + "',Entered_Date='" + Entered_Date + "',Revised_Date='" + Revised_Date + "',Completed='" + 1 + "'  where id=" + newsId + "";

                    }
                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            out.print("Data Inserted");
                        } else {
                            out.print("Data Updated Successfully and you are redirecting to News_Manager");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }
                
                case "saveUser": {
                    String username = request.getParameter("username");
                    String phone_No = request.getParameter("phone_No");
                    String mail_Id = request.getParameter("mail_Id");
                    String password = request.getParameter("password");
                    String role = request.getParameter("role");
                    String department = request.getParameter("department");
                    String user = request.getParameter("user");
                    java.sql.Timestamp enteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp Revised_Date = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into usermaster "
                                + "(username,phone_No,mail_Id,password,role,department,Entered_Date,Entered_By) "
                                + "values('" + username + "','" + phone_No + "','" + mail_Id + "','" + password + "','" + role + "','" + department + "','" + enteredDate + "','" + user + "')";
                    } else {
                        sql = "update usermaster set username='" + username + "',phone_No='" + phone_No + "',mail_Id='" + mail_Id + "',password='" + password + "',role='" + role + "',department='" + department + "',Revised_Date='" + Revised_Date + "' where id=" + ID + "";

                    }

                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (("0".equals(ID)) && success > 0) {
                            out.print("Data Inserted");
                        } else {
                            out.print("Data Updated Successfully and you are redirecting to User_Master");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "saveCompany": {

                    String Company_name = request.getParameter("Company_name");
                    String News_Channel = request.getParameter("News_Channel");
                    String Company_address = request.getParameter("Company_address");
                    String phoneNo = request.getParameter("phoneNo");
                    String Email_id = request.getParameter("Email_id");
                    String user = request.getParameter("user");

                    java.sql.Timestamp Entered_Date = new java.sql.Timestamp(curDate.getTime());

                    PrintWriter out = response.getWriter();

                    String Sql = "";
                    if (checkcompany()) {
                        Sql = "update company_details set Company_name='" + Company_name + "',News_Channel='" + News_Channel + "',Company_address='" + Company_address + "',phoneNo='" + phoneNo + "',Email_id='" + Email_id + "' where Id=1";
                        out.print("Data Updated");
                    } else {
                        Sql = "insert into company_details "
                                + "(Company_name,News_Channel,Company_address,phoneNo,Email_id,Entered_by,Entered_Date)"
                                + "values('" + Company_name + "','" + News_Channel + "','" + Company_address + "','"
                                + phoneNo + "','" + Email_id + "','" + user + "','" + Entered_Date + "')";

                        out.print("Data Inserted");
                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(Sql);
                        int success = ps.executeUpdate();

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;
                case "saveProfile": {
                    String username = request.getParameter("username");
                    String phone_No = request.getParameter("phone_No");
                    String mail_Id = request.getParameter("mail_Id");
                    String password = request.getParameter("password");
                    String role = request.getParameter("role");
                    String department = request.getParameter("department");
                    String user = request.getParameter("user");
                    java.sql.Timestamp enteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp Revised_Date = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {

                        sql = "update usermaster set password='" + password + "',Revised_Date='" + Revised_Date + "' where id=" + ID + "";

                    }

                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (("0".equals(ID)) && success > 0) {
                            out.print("Data Inserted");
                        } else {
                            out.print("Data Updated Successfully and you are redirecting to Profile Page");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "Delete": {

                    String table = request.getParameter("tbl");

                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "Delete from " + table + " where id=" + ID + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            out.print("Data deleted Successfully");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }

                break;
                default:
                    break;
                    

            }
        }
    }

    private boolean checkcompany() {
        String sql = "";

        sql = "select * from company_details where id=1";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                return true;
            }

        } catch (SQLException ex) {
            Logger.getLogger(newsServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

}
