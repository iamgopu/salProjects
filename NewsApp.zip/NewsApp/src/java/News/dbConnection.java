package News;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class dbConnection {

    private static Connection con;

    static {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://103.83.81.126/salclust_dinmannews?useUnicode=true&characterEncoding=utf-8", "praveen", "Software");

        } catch (ClassNotFoundException | SQLException ex) {
            System.out.print(ex);
        }
    }

    public static Connection getCon() {
        return con;
    }

}
