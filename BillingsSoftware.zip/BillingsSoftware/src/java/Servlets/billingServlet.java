package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "billingServlet", urlPatterns = {"/billingServlet"})

public class billingServlet extends HttpServlet {

    Connection con = dbConnection.getcon();
    java.util.Date curDate = new java.util.Date();
    StringBuilder htmldata = new StringBuilder();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (null != action) {
            switch (action) {
                case "TableCustomer": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Customer Name</th>\n"
                            + "                <th>Billing Address</th>\n"
                            + "                <th>Shipping Address</th>\n"
                            + "                <th>City</th>\n"
                            + "                <th>Pincode</th>\n"
                            + "                <th>State</th>\n"
                            + "                <th>GST Code</th>\n"
                            + "                <th>GSTIN</th>\n"
                            + "                <th>Status</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from customer_master";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("Customer_Name") + "</td>\n"
                                    + "                <td>" + rs.getString("billing_address") + "</td>\n"
                                    + "                <td>" + rs.getString("shipping_address") + "</td>\n"
                                    + "                <td>" + rs.getString("City") + "</td>\n"
                                    + "                <td>" + rs.getString("Pincode") + "</td>\n"
                                    + "                <td>" + rs.getString("State") + "</td>\n"
                                    + "                <td>" + rs.getString("GST_Code") + "</td>\n"
                                    + "                <td>" + rs.getString("GSTIN") + "</td>\n"
                                    + "                <td>" + rs.getString("status") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><button type =\"button\" class=\"close\" onClick=\"Delete(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-trash-o\" style=\"font-size:20px;color:red\"></i></button>"
                                    + "<button type =\"button\" class=\"close\" onClick=\"getdataforedit(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-edit\" style=\"font-size:20px;color:blue\"></i></button></td>");

                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "TableSalesOrder": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Customer Name</th>\n"
                            + "                <th>SO NO</th>\n"
                            + "                <th>Valid From</th>\n"
                            + "                <th>Valid To</th>\n"
                            + "                <th>Type</th>\n"
                            + "                <th>Sales Order Date</th>\n"
                            + "                <th>Terms</th>\n"
                            + "                <th>Status</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "                <th>Item Details</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select cwp.id,cm.Customer_Name as Customer_Name,PO_No,validFrom,validTo,Type,soDate,terms,cwp.Status,"
                            + "cwp.EnteredBy,cwp.EnteredDate,cwp.RevisedBy,cwp.RevisedDate from sales_order cwp "
                            + " left join customer_Master cm on (cwp.Customer_Name = cm.id) order by id desc";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("Customer_Name") + "</td>\n");
                            if ("0".equals(rs.getString("PO_No"))) {
                                out.print("<td>---</td>");
                            } else {
                                out.print("<td>" + rs.getString("PO_No") + "</td>");
                            }
                            out.print("<td>" + rs.getString("validFrom") + "</td>\n");
                            out.print("<td>" + rs.getString("validTo") + "</td>\n");
                            out.print("<td>" + rs.getString("Type") + "</td>\n");
                            out.print("<td>" + rs.getString("soDate") + "</td>\n");
                            if ("0".equals(rs.getString("terms"))) {
                                out.print("<td>Immediate</td>");
                            } else {
                                out.print("<td>" + rs.getString("terms") + "</td>");
                            }
                            out.print("<td>" + rs.getString("Status") + "</td>\n");
                            out.print("<td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><button type =\"button\" class=\"close\" onClick=\"DeleteSalesDetails(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-trash-o\" style=\"font-size:20px;color:red\"></i></button>"
                                    + "<button type =\"button\" class=\"close\" onClick=\"getSalesDetailsdataforedit(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-edit\" style=\"font-size:20px;color:blue\"></i></button></td>");

                            out.print("<td><a class=\"btn btn-primary btn-special\" id=\"changetabbutton\" onClick=\"activaTab('" + rs.getString(1) + "')\">Add/View Item</a></td>"
                                    + "            </tr>\n");

                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "TableItemDetails": {
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    String sorefid = request.getParameter("sorefid");
                    out.print("<table id=\"example1\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Item Name</th>\n"
                            + "                <th>UOM</th>\n"
                            + "                <th>Quantity</th>\n"
                            + "                <th>Rate</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select o.id,im.Item_Name as itemId, o.uom, quantity as qty , rate,"
                            + "o.EnteredBy as ENteredBy,o.EnteredDate as EnteredDate,o.RevisedBy as RevisedBy,o.RevisedDate as RevisedDate from ordered_item o "
                            + " left join item_master im on (o.itemId = im.id) where sorefid=" + sorefid + " order by id desc";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("itemId") + "</td>\n"
                                    + "                <td>" + rs.getString("uom") + "</td>\n"
                                    + "                <td>" + rs.getString("qty") + "</td>\n"
                                    + "                <td>" + rs.getString("rate") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><button type =\"button\" class=\"close\" onClick=\"DeleteItemDetails(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-trash-o\" style=\"font-size:20px;color:red\"></i></button>"
                                    + "<button type =\"button\" class=\"close\" onClick=\"getItemDetailsdataforedit(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-edit\" style=\"font-size:20px;color:blue\"></i></button></td>"
                                    + "            </tr>\n"
                                    + " ");

                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "TableHsnMaster": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>HSN Code</th>\n"
                            + "                <th>Description</th>\n"
                            + "                <th>IGST</th>\n"
                            + "                <th>CGST</th>\n"
                            + "                <th>SGST</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from hsn_master";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("HSN_Code") + "</td>\n"
                                    + "                <td>" + rs.getString("Description") + "</td>\n"
                                    + "                <td>" + rs.getString("IGST") + "</td>\n"
                                    + "                <td>" + rs.getString("CGST") + "</td>\n"
                                    + "                <td>" + rs.getString("SGST") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><button type =\"button\" class=\"close\" onClick=\"Delete(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-trash-o\" style=\"font-size:20px;color:red\"></i></button>"
                                    + "<button type =\"button\" class=\"close\" onClick=\"getdataforedit(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-edit\" style=\"font-size:20px;color:blue\"></i></button></td>"
                                    + "            </tr>\n"
                                    + " ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "TableItemMaster": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Item Name</th>\n"
                            + "                <th>UOM</th>\n"
                            + "                <th>Make</th>\n"
                            + "                <th>HSN_Code</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select i.id,Item_Name,u.UOM_Description as UOM,Make,HSN_Code,i.EnteredBy,i.EnteredDate,i.RevisedBy,i.RevisedDate"
                            + " from item_master i "
                            + " left join uom_master u on (i.UOM = u.id) ";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("Item_Name") + "</td>\n"
                                    + "                <td>" + rs.getString("UOM") + "</td>\n"
                                    + "                <td>" + rs.getString("Make") + "</td>\n"
                                    + "                <td>" + rs.getString("HSN_Code") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><button type =\"button\" class=\"close\" onClick=\"Delete(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-trash-o\" style=\"font-size:20px;color:red\"></i></button>"
                                    + "<button type =\"button\" class=\"close\" onClick=\"getdataforedit(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-edit\" style=\"font-size:20px;color:blue\"></i></button></td>"
                                    + "            </tr>\n"
                                    + " ");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "TableUOM": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>UOM Code</th>\n"
                            + "                <th>UOM Description</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from uom_master";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("UOM_Code") + "</td>\n"
                                    + "                <td>" + rs.getString("UOM_Description") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }

                            out.print("<td><button type =\"button\" class=\"close\" onClick=\"Delete(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-trash-o\" style=\"font-size:20px;color:red\"></i></button>"
                                    + "<button type =\"button\" class=\"close\" onClick=\"getdataforedit(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-edit\" style=\"font-size:20px;color:blue\"></i></button></td>"
                                    + "            </tr>\n"
                                    + " ");

                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "TableInvoice": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Invoice No</th>\n"
                            + "                <th>Invoice Date</th>\n"
                            + "                <th>Due Date</th>\n"
                            + "                <th>Customer Name</th>\n"
                            + "                <th>No. of Items</th>\n"
                            + "                <th>Total Amount</th>\n"
                            + "                <th>Status</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select i.id,cm.Customer_Name as customerName,invoiceNo,invoiceDate,dueDate,count(distinct ii.itemid) as itemddl,"
                            + "sum(ii.totalamt) as totalamt,i.status,i.EnteredBy,i.EnteredDate,i.RevisedBy,i.RevisedDate from invoice i "
                            + " left join customer_master cm on(i.customerName=cm.id)"
                            + " left join invoiceitems ii on (i.id = ii.invoiceId) group by invoiceId order by invoiceNo desc";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("invoiceNo") + "</td>\n"
                                    + "                <td>" + rs.getString("invoiceDate") + "</td>\n"
                                    + "                <td>" + rs.getString("dueDate") + "</td>\n"
                                    + "                <td>" + rs.getString("customerName") + "</td>\n"
                                    + "                <td>" + rs.getString("itemddl") + "</td>\n"
                                    + "                <td>" + rs.getString("totalamt") + "</td>\n"
                                    + "                <td>" + rs.getString("status") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><a class=\"btn btn-primary btn-sm\" onClick=\"getdataforedit(" + rs.getString("id") + "," + rs.getString("itemddl") + ")\">Edit</a><br>"
                                    + "<a class=\"btn btn-primary btn-sm\" onClick=\"invprint(" + rs.getString("invoiceNo") + ") \">Preview</a><br>\n"
                                    + "<a class=\"btn btn-danger btn-sm\" onClick=\"Delete(" + rs.getString("id") + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + " ");

                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "GetInnerInvoiceTableData": {
                    String InvoiceId = request.getParameter("invoiceId");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"myTable\" class=\" table order-list\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Sr.No</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Item Name</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">HSN Code</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">UOM</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Quantity</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Rate</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Total</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Discount</th>\n"
                            + "                <th class=\"text-center\" colspan=\"3\">GST</th>\n"
                            + "                <th class=\"text-center\" colspan=\"3\">Actions</th>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <th class=\"text-center\">IGST</th>\n"
                            + "                <th class=\"text-center\">CGST</th>\n"
                            + "                <th class=\"text-center\">SGST</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");

                    sql = "select id,itemId,hsn,uom,Qty,Rate,total,Discount,igst,cgst,sgst,totalamt,RevisedBy,RevisedDate from invoiceitems "
                            + "where invoiceId=" + InvoiceId + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            String idstr = String.valueOf(i);
                            String htmlcode = itemdropdownhtml(String.valueOf(i), rs.getString("itemId"));
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + htmlcode + "</td>\n"
                                    + "                <td><input type=\"text\" name='hsn' class=\"form-control\" style=\"width: 80px;\" id=\"hsn" + idstr + "\" value=\"" + rs.getString("hsn") + "\"/></td>\n"
                                    + "                <td><input type=\"text\" name='uom' class=\"form-control\" style=\"width: 70px;\" id=\"uom" + idstr + "\" value=\"" + rs.getString("uom") + "\"></td>\n"
                                    + "                <td><input type=\"text\" name='Qty' onkeypress=\"return (event.charCode > 47 && event.charCode < 58) || (event.keyCode == 8) ||\n"
                                    + "                                                                        (event.keyCode == 46)\" class=\"form-control\" style=\"width: 70px;\" id=\"Qty" + idstr + "\" value=\"" + rs.getString("Qty") + "\"/></td>\n"
                                    + "                <td><input type=\"text\" name='Rate' onkeypress=\"return (event.charCode > 47 && event.charCode < 58) || (event.keyCode == 8) ||\n"
                                    + "                                                                        (event.keyCode == 46)\" class=\"form-control\" style=\"width: 70px;\" id=\"Rate" + idstr + "\" onchange=\"caltotal(this.id);\" value=\"" + rs.getString("rate") + "\"/></td>\n"
                                    + "                <td><input type=\"text\" name='total' class=\"form-control\" readonly style=\"width: 70px;\" id=\"total" + idstr + "\" value=\"" + rs.getString("total") + "\"/></td>\n"
                                    + "                <td><input type=\"text\" name='Discount' onkeypress=\"return (event.charCode > 47 && event.charCode < 58) || (event.keyCode == 8) ||\n"
                                    + "                                                                        (event.keyCode == 46)\" class=\"form-control\" style=\"width: 70px;\" id=\"Discount" + idstr + "\" onchange=\"caltotalamt(this.id);\" value=\"" + rs.getString("Discount") + "\"/></td>\n"
                                    + "                <td><input type=\"text\" name='igst' class=\"form-control\" readonly style=\"width: 70px;\" id=\"igst" + idstr + "\" value=\"" + rs.getString("igst") + "\"/ ></td>\n"
                                    + "                <td><input type=\"text\" name='cgst' class=\"form-control\" readonly style=\"width: 70px;\" id=\"cgst" + idstr + "\" value=\"" + rs.getString("cgst") + "\"/></td>\n"
                                    + "                <td><input type=\"text\" name='sgst' class=\"form-control\" readonly style=\"width: 70px;\" id=\"sgst" + idstr + "\" value=\"" + rs.getString("sgst") + "\"/></td>\n"
                                    + "                <td><input type=\"text\" name='totalamt' class=\"form-control\" readonly style=\"width: 70px;\" id=\"totalamt" + idstr + "\" value=\"" + rs.getString("totalamt") + "\"/></td>\n"
                                    + "                <td><a class=\"btn btn-danger btn-sm\" onClick=\"deleteOnEditInvoice(" + rs.getString("id") + "," + InvoiceId + ") \">Delete</a></td>\n"
                                    + "            </tr>\n"
                                    + " ");

                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table> -- " + String.valueOf(i));
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "GetInnerInvoiceTableDataforpreview": {
                    String InvoiceId = request.getParameter("invoiceId");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    StringBuilder tabl = new StringBuilder();
                    tabl.append("<table id=\"myTable\" class=\" table order-list\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Sr.No</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Item Name</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">HSN Code</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">UOM</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Quantity</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Rate</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Total</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Discount</th>\n"
                            + "                <th class=\"text-center\" colspan=\"3\">GST</th>\n"
                            + "                <th class=\"text-center\" rowspan=\"2\">Total Amount</th>\n"
                            + "            </tr>\n"
                            + "            <tr>\n"
                            + "                <th class=\"text-center\">IGST</th>\n"
                            + "                <th class=\"text-center\">CGST</th>\n"
                            + "                <th class=\"text-center\">SGST</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");

                    sql = "select item_name,hsn,uom,Qty,Rate,total,Discount,igst,cgst,sgst,totalamt,RevisedBy,RevisedDate from invoiceitems ii "
                            + " left join (select item_name,id from item_master )  im on (ii.itemid=im.id) where invoiceId=" + InvoiceId + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;

                            tabl.append(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td> " + rs.getString("item_name") + "</td>\n"
                                    + "                <td>" + rs.getString("hsn") + "</td>\n"
                                    + "                <td>" + rs.getString("uom") + "</td>\n"
                                    + "                <td>" + rs.getString("Qty") + "</td>\n"
                                    + "                <td>" + rs.getString("rate") + "</td>\n"
                                    + "                <td>" + rs.getString("total") + "</td>\n"
                                    + "                <td>" + rs.getString("Discount") + "</td>\n"
                                    + "                <td>" + rs.getString("igst") + "</td>\n"
                                    + "                <td>" + rs.getString("cgst") + "</td>\n"
                                    + "                <td>" + rs.getString("sgst") + "</td>\n"
                                    + "                <td>" + rs.getString("totalamt") + "</td>\n"
                                    + "            </tr>\n"
                                    + " ");

                        }
                        tabl.append("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                        out.print(tabl);
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;
                case "TableReason": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Reason Code</th>\n"
                            + "                <th>Reason Description</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Actions</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select * from reason_master";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("ID") + "</td>\n"
                                    + "                <td>" + rs.getString("Reason_Description") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }

                            out.print("<td><button type =\"button\" class=\"close\" onClick=\"Delete(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-trash-o\" style=\"font-size:20px;color:red\"></i></button>"
                                    + "<button type =\"button\" class=\"close\" onClick=\"getdataforedit(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-edit\" style=\"font-size:20px;color:blue\"></i></button></td>");

                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "InvoiceTableForPayment": {
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    out.print("<table id=\"example1\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Invoice No</th>\n"
                            + "                <th>Customer Name</th>\n"
                            + "                <th>Gross Value</th>\n"
                            + "                <th>Status</th>\n"
                            + "                <th>Invoice Date</th>\n"
                            + "                <th>Terms</th>\n"
                            + "                <th>Due Date</th>\n"
                            + "                <th>Due Days</th>\n"
                            + "                <th>View Invoice</th>\n"
                            + "                <th>Add Receipt</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select i.id,cm.Customer_Name as customerName,i.invoiceNo as invoiceNo,i.invoiceDate as invoiceDate,i.terms as terms,"
                            + "i.dueDate as dueDate,DATEDIFF(curdate(),i.dueDate) as dueDays, sum(ii.totalamt) as grossValue,i.status from invoice i "
                            + " left join invoiceitems ii on (ii.invoiceid = i.id)"
                            + " left join customer_master cm on(i.customerName = cm.id)"
                            + " where i.close='0' group by invoiceNo order by id desc";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("invoiceNo") + "</td>\n"
                                    + "                <td>" + rs.getString("customerName") + "</td>\n"
                                    + "                <td>" + rs.getString("grossValue") + "</td>\n"
                                    + "                <td>" + rs.getString("status") + "</td>\n"
                                    + "                <td>" + rs.getString("invoiceDate") + "</td>\n"
                                    + "                <td>" + rs.getString("terms") + "</td>\n"
                                    + "                <td>" + rs.getString("dueDate") + "</td>\n");
                            if (rs.getInt("dueDays") < 0) {
                                out.print("<td style=\"color: red\"><strong>" + rs.getString("dueDays") + "</strong></td>");
                            } else {
                                out.print("<td style=\"color: black\"><strong>" + rs.getString("dueDays") + "</strong></td>");
                            }
                            out.print("<td><a class=\"btn btn-primary\"  onclick=\"ViewInvoice(" + rs.getString("invoiceNo") + ")\">View Invoice</a></td>\n");
                            out.print("<td><a class=\"btn btn-primary\"  onclick=\"getinvoicedataforpayment(" + rs.getString("Id") + ")\">Receipt Entry</a></td>\n"
                                    + "            </tr>\n");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "InvoiceTableForPaid": {
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    out.print("<table id=\"example2\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Invoice No</th>\n"
                            + "                <th>Invoice Date</th>\n"
                            + "                <th>Customer Name</th>\n"
                            + "                <th>Gross Value</th>\n"
                            + "                <th>Received Amount</th>\n"
                            + "                <th>Received Date</th>\n"
                            + "                <th>Payment mode</th>\n"
                            + "                <th>Status</th>\n"
                            + "                <th>Entered Details</th>\n"
                            + "                <th>Revised Details </th>\n"
                            + "                <th>Action</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select r.id,cm.Customer_Name as customerName,i.invoiceNo as invoiceNo,i.invoiceDate as invoiceDate,sum(ii.totalamt) as grossValue,i.status as status,"
                            + "r.receivedAmount,r.Modeofpayment,r.receivedDate, r.EnteredBy,r.EnteredDate,r.RevisedBy,"
                            + "r.RevisedDate from received r "
                            + " left join invoice i on (r.invoiceid=i.id)"
                            + " left join invoiceitems ii on (ii.invoiceid = i.id) "
                            + " left join customer_master cm on (i.customerName = cm.id) order by r.id desc";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + " <td>" + i + "</td>\n"
                                    + " <td>" + rs.getString("invoiceNo") + "</td>\n"
                                    + " <td>" + rs.getString("invoiceDate") + "</td>\n"
                                    + " <td>" + rs.getString("customerName") + "</td>\n"
                                    + " <td>" + rs.getString("grossValue") + "</td>\n"
                                    + " <td>" + rs.getString("receivedAmount") + "</td>\n"
                                    + " <td>" + rs.getString("receivedDate") + "</td>\n"
                                    + " <td>" + rs.getString("ModeOfPayment") + "</td>\n"
                                    + " <td>" + rs.getString("status") + "</td>\n"
                                    + " <td>" + rs.getString("EnteredBy") + " <br>" + rs.getString("EnteredDate") + "</br></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><button type =\"button\" class=\"close\" onClick=\"getpaymentdataforedit(" + rs.getString("ID") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-edit\" style=\"font-size:20px;color:blue\"></i></button></td>");
                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "TableSalesReturn": {
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    out.print("<table id=\"example\" class=\"table table-striped table-bordered\" style=\"width:100%\">\n"
                            + "        <thead>\n"
                            + "            <tr>\n"
                            + "                <th>Sr.No</th>\n"
                            + "                <th>Invoice No</th>\n"
                            + "                <th>Customer Name</th>\n"
                            + "                <th>Invoice Date</th>\n"
                            + "                <th>Order No</th>\n"
                            + "                <th>Billing Address</th>\n"
                            + "                <th>Net Amount</th>\n"
                            + "                <th>GST Value</th>\n"
                            + "                <th>Gross Value</th>\n"
                            + "                <th>Reason</th>\n"
                            + "                <th>Created Details</th>\n"
                            + "                <th>Revised Details</th>\n"
                            + "                <th>Action</th>\n"
                            + "            </tr>\n"
                            + "        </thead>\n"
                            + "        <tbody>");
                    sql = "select s.id,i.invoiceNo as invoiceNo, s.customerName,s.invoiceDate,s.orderNo,s.Billing_Address,s.netvalue,"
                            + "s.gstvalue,s.grossvalue,reason,s.enteredby,s.entereddate,s.revisedby,s.reviseddate from salesreturn s"
                            + " left join invoice i on(s.invoiceNo = i.id) order by invoiceNo desc";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {
                            i++;
                            out.print(" <tr>\n"
                                    + "                <td>" + i + "</td>\n"
                                    + "                <td>" + rs.getString("invoiceNo") + "</td>\n"
                                    + "                <td>" + rs.getString("customerName") + "</td>\n"
                                    + "                <td>" + rs.getString("invoiceDate") + "</td>\n"
                                    + "                <td>" + rs.getString("orderNo") + "</td>\n"
                                    + "                <td>" + rs.getString("Billing_Address") + "</td>\n"
                                    + "                <td>" + rs.getString("netvalue") + "</td>\n"
                                    + "                <td>" + rs.getString("gstvalue") + "</td>\n"
                                    + "                <td>" + rs.getString("grossvalue") + "</td>\n"
                                    + "                <td>" + rs.getString("reason") + "</td>\n"
                                    + "                <td>" + rs.getString("EnteredBy") + " <br/>" + rs.getString("EnteredDate") + "<br/></td>\n");
                            if (rs.getString("RevisedBy") == null && rs.getString("RevisedDate") == null) {
                                out.print("<td>Not Updated Yet!</td>");
                            } else {
                                out.print("<td>" + rs.getString("RevisedBy") + " <br/>" + rs.getString("RevisedDate") + "<br/></td>");
                            }
                            out.print("<td><button type =\"button\" class=\"close\" onClick=\"Delete(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-trash-o\" style=\"font-size:20px;color:red\"></i></button>"
                                    + "<button type =\"button\" class=\"close\" onClick=\"getdataforedit(" + rs.getString("id") + ")\" style=\"margin-right: 20%;\"><i class=\"fa fa-edit\" style=\"font-size:20px;color:blue\"></i></button></td>");

                        }
                        out.print("  </tbody>\n"
                                + "      \n"
                                + "    </table>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "customerdropdown": {
                    String sql = "select * from customer_master";
                    PrintWriter out = response.getWriter();

                    out.print(" <select class=\"form-control\" type=\"text\" name=\"customerName\" autocomplete=\"off\" id=\"customerName\" onChange=\"getaddress(this.value)\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option>Select Customers</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("Customer_Name") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "orderNoDropDown": {
                    String Id = request.getParameter("customerId");
                    String sql = "select * from sales_order where customer_name = " + Id + "";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"sorderNo\" autocomplete=\"off\" id=\"sorderNo\" onChange=\"getTerms(this.value)\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option>Select Order Number</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("id") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "customerddlforpo": {
                    String sql = "select * from customer_master";
                    PrintWriter out = response.getWriter();

                    out.print(" <select class=\"form-control\" type=\"text\" name=\"Customer_Name\" autocomplete=\"off\" id=\"Customer_Name\" onChange=\"getpostatus(this.value)\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option>Select Customers</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("Customer_Name") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
                break;

                case "getpostatusfromcustomer": {
                    String postat = request.getParameter("customerId");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select close from customer_master where id = " + postat + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("close"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "getaddress": {
                    String Id = request.getParameter("customerId");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select Billing_Address,Shipping_Address,GST_Code from customer_master where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("Billing_Address") + " -- " + rs.getString("Shipping_Address") + " -- " + rs.getString("GST_Code"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "getStateCodefromsetup": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from setup";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("StateCode"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "getStateCodefromcustomer": {
                    String customerId = request.getParameter("customerId");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from customer_master where id = " + customerId + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("GST_Code"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "gettermsforinvoice": {
                    String sorderNo = request.getParameter("sorderNo");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from sales_order where id=" + sorderNo + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("PO_No") + " -- " + rs.getString("terms"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "itemddl": {
                    String sorderNo = request.getParameter("soref");

                    String sql = "select im.item_name,oi.itemid from ordered_item oi left join item_master im on (oi.itemId=im.id) where oi.sorefid=" + sorderNo + " ";
                    PrintWriter out = response.getWriter();
                    String inputid = request.getParameter("counter");
                    out.print(" <select class=\"chosen\" id=\"itemddl" + inputid + "\" style=\"width: 170px;\" onChange=\"getHsnCode(this.value,this.id)\">\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option>Select Item</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString(2) + "'>" + rs.getString(1) + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "itemrate": {
                    String sorderNo = request.getParameter("soref");
                    String itemid = request.getParameter("itemid");

                    String sql = "select rate,quantity from ordered_item where SoRefId=" + sorderNo + " and itemid=" + itemid + "";
                    PrintWriter out = response.getWriter();
                    String inputid = request.getParameter("counter");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;

                        while (rs.next()) {
                            out.print(rs.getString("rate") + " -- " + rs.getString("quantity"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;
                case "getitemdatafororder": {
                    String sql = "select * from item_master";
                    PrintWriter out = response.getWriter();

                    out.print(" <select class=\"form-control\" type=\"text\" name=\"itemName\" autocomplete=\"off\" id=\"itemName\" onchange=\"getUomDataForItemDetails(this.value)\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option>Select Item</option>\n");

                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("Item_Name") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        out.print(ex);
                    }

                }
                break;

                case "GetCustomerData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from customer_master where id=" + Id + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("Customer_Name") + " -- " + rs.getString("billing_address") + " -- " + rs.getString("shipping_address") + " -- "
                                    + "" + rs.getString("City") + " -- " + rs.getString("Pincode") + " -- "
                                    + rs.getString("State") + " -- " + rs.getString("GST_Code")
                                    + " -- " + rs.getString("GSTIN") + " -- " + rs.getString("status") + " -- "
                                    + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetSalesDetailsData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from sales_order where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("Customer_Name") + " -- " + rs.getString("PO_No") + " -- " + "" + rs.getString("validFrom") + " -- "
                                    + rs.getString("validTo") + " -- " + rs.getString("Type") + " -- " + rs.getString("soDate") + " -- "
                                    + rs.getString("terms") + " -- " + rs.getString("Status") + " -- "
                                    + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- "
                                    + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "getbasicsalesorderdata": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select cm.Customer_Name as customerName,cwp.Po_No as Po,cwp.id  as So from sales_order cwp"
                            + " left join customer_master cm on (cwp.Customer_Name = cm.id) where cwp.id=" + Id + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("customerName") + " -- " + rs.getString("Po") + " -- " + "" + rs.getString("So"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetItemDetailsData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from ordered_item where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("itemId") + " -- " + rs.getString("uom") + " -- " + "" + rs.getString("quantity") + " -- "
                                    + rs.getString("rate") + " -- " + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- "
                                    + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetHsnData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from hsn_master where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("HSN_Code") + " -- " + rs.getString("Description") + " -- "
                                    + "" + rs.getString("SGST") + " -- " + rs.getString("CGST")
                                    + " -- " + rs.getString("IGST") + " -- "
                                    + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetItemData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from item_master where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("Item_Name") + " -- " + rs.getString("UOM") + " -- "
                                    + "" + rs.getString("Make") + " -- " + rs.getString("HSN_Code")
                                    + " -- "
                                    + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;
                case "GetSetupData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from setup where id=" + Id + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("CompanyName") + " -- " + rs.getString("MobileNo") + " -- " + "" + rs.getString("Email")
                                    + " -- " + rs.getString("State") + " -- " + rs.getString("statecode") + " -- " + rs.getString("GSTIN") + " -- " + rs.getString("PanNo")
                                    + " -- " + rs.getString("Address") + " -- " + rs.getString("Account_Name") + " -- " + rs.getString("Bank_Name")
                                    + " -- " + "" + rs.getString("Account_No") + " -- " + rs.getString("Branch_Name") + " -- "
                                    + rs.getString("IFSC_Code") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetUomData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from uom_master where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("UOM_Code") + " -- " + rs.getString("UOM_Description")
                                    + " -- "
                                    + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetInvoiceData": {
                    String id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select i.id,customerName,invoiceNo,sorderNo,PO_No,invoiceDate,terms,dueDate,i.status as status,"
                            + "i.RevisedBy,i.RevisedDate from invoice i where i.id=" + id + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("invoiceNo") + " -- " + rs.getString(2) + " -- " + "" + rs.getString("sorderNo") + " -- " + "" + rs.getString("PO_No")
                                    + " -- " + rs.getString("invoiceDate") + " -- " + rs.getString("terms") + " -- " + rs.getString("dueDate")
                                    + " -- " + rs.getString("status") + " -- " + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "autoinvoice": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select max(invoiceNo) as invoiceNo from invoice";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("invoiceNo"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetReasonData": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from reason_master where id=" + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("Reason_Description") + " -- " + rs.getString("RevisedBy") + " -- "
                                    + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "GetPaymentData": {
                    String id = request.getParameter("ID");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    sql = "select r.id,cm.Customer_Name as customerName,i.invoiceNo,sum(ii.totalamt) as grossValue,i.status as status,receivedAmount,"
                            + "Modeofpayment,r.receivedDate, r.EnteredBy,r.EnteredDate,r.RevisedBy,r.RevisedDate from received r "
                            + " Left join invoice i on (r.invoiceid = i.id) "
                            + " left join invoiceitems ii on (ii.invoiceId = i.id)"
                            + " left join customer_master cm on (i.customerName = cm.id) "
                            + "where r.id= " + id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("invoiceNo") + " -- " + rs.getString("customerName") + " -- "
                                    + rs.getString("grossvalue") + " -- " + rs.getString("receivedAmount") + " -- " + rs.getString("receivedDate") + " -- "
                                    + rs.getString("ModeOfPayment") + " -- " + rs.getString("Status") + " -- " + rs.getString("RevisedBy") + " -- "
                                    + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetSalesReturnData": {
                    String id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select s.id,i.invoiceNo as invoiceNo, s.customerName,s.invoiceDate,s.orderNo,s.Billing_Address,s.netvalue,"
                            + "s.gstvalue,s.grossvalue,reason,s.enteredby,s.entereddate,s.revisedby,s.reviseddate from salesreturn s"
                            + " left join invoice i on(s.invoiceNo = i.id) where s.id=" + id + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("invoiceNo") + " -- " + rs.getString("customerName") + " -- " + "" + rs.getString("invoiceDate")
                                    + " -- " + rs.getString("orderNo") + " -- " + rs.getString("Billing_Address") + " -- " + rs.getString("netvalue")
                                    + " -- " + rs.getString("gstvalue") + " -- " + rs.getString("grossvalue") + " -- " + rs.getString("reason")
                                    + " -- " + rs.getString("RevisedBy") + " -- " + rs.getString("RevisedDate") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetHsnCode": {
                    String Id = request.getParameter("id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select im.id,im.hsn_code,um.uom_code as uom,hm.SGST,hm.CGST,hm.IGST from item_master im "
                            + "Left join Hsn_master hm on (hm.hsn_code=im.hsn_code) "
                            + "left join uom_master um on (im.uom = um.id)"
                            + "where im.id='" + Id + "'";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString(2) + " -- "
                                    + "" + rs.getString(3) + " -- " + rs.getString(4)
                                    + " -- " + rs.getString(5) + " -- " + rs.getString(6));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "GetInvoiceDataForPayment": {
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select i.id,cm.Customer_Name as customerName,invoiceNo,sum(ii.totalamt) as grossValue,"
                            + "i.Status from invoice i"
                            + " left join invoiceitems ii on (ii.invoiceid = i.id) "
                            + " left join customer_master cm on (i.customerName = cm.id) where i.id=" + Id + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("invoiceNo") + " -- " + rs.getString("customerName") + " -- "
                                    + rs.getString("grossValue") + " -- " + rs.getString("Status") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "getinvoicedataforsalesreturn": {
                    String Id = request.getParameter("invoiceNo");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select i.id,cm.Customer_Name AS customerName,i.invoiceDate,i.sorderNo as orderNo,i.Billing_Address as Billing_Address,sum(ii.total) as netvalue,\n"
                            + "sum(ii.igst + ii.cgst + ii.sgst) as gstvalue,sum(ii.totalamt) as grossvalue,i.Status as status from invoice i \n"
                            + " left join invoiceitems ii on (ii.invoiceId = i.id) "
                            + " left join customer_master cm on(i.customerName=cm.id) group by ii.invoiceid having i.id = " + Id + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("customerName") + " -- " + rs.getString("invoiceDate") + " -- " + rs.getString("orderNo") + " -- " + rs.getString("Billing_Address") + " -- " + rs.getString("netvalue") + " -- "
                                    + rs.getString("gstvalue") + " -- " + rs.getString("grossvalue") + " -- " + rs.getString("status") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "getCompanyDataForPrint": {
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select * from setup";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("CompanyName") + " -- " + rs.getString("Address") + " -- " + rs.getString("MobileNo")
                                    + " -- " + rs.getString("Email") + " -- " + rs.getString("PanNo") + " -- " + rs.getString("GSTIN")
                                    + " -- " + rs.getString("State") + " -- " + rs.getString("statecode") + " -- " + rs.getString("Bank_Name") + " -- " + rs.getString("Account_No")
                                    + " -- " + rs.getString("IFSC_Code") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "getInvoiceDataForPrint": {
                    String invoiceno = request.getParameter("invoiceno");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "select i.id,invoiceNo,invoiceDate,terms,dueDate,cm.Customer_Name as customerName,i.Billing_Address as Billing_Address,cm.gstin as BGSTIN,"
                            + "cm.state as Bstate,cm.GST_Code as BGST_Code,sorderNo as BorderNo,i.Shipping_Address as Shipping_Address,cm.gstin as SGSTIN,"
                            + "cm.state as Sstate,cm.GST_Code as SGST_Code,sorderNo as SorderNo,sum(ii.total) as subtotal, "
                            + "sum(ii.cgst) as totalcgst,sum(ii.sgst) as totalsgst,sum(ii.totalamt) as grossamt from invoice i "
                            + " left join invoiceitems ii on (i.invoiceNo = ii.invoiceid) "
                            + " left join customer_master cm on (i.customerName = cm.id) where invoiceNo = " + invoiceno + " group by ii.invoiceid";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("invoiceNo") + " -- " + rs.getString("invoiceDate") + " -- " + rs.getString("terms")
                                    + " -- " + rs.getString("dueDate") + " -- " + rs.getString("customerName") + " -- " + rs.getString("Billing_Address")
                                    + " -- " + rs.getString("BGSTIN") + " -- " + rs.getString("Bstate") + " -- " + rs.getString("BGST_Code")
                                    + " -- " + rs.getString("BorderNo") + " -- " + rs.getString("Shipping_Address") + " -- " + rs.getString("SGSTIN")
                                    + " -- " + rs.getString("Sstate") + " -- " + rs.getString("SGST_Code") + " -- " + rs.getString("SorderNo") + " -- " + rs.getString("subtotal")
                                    + " -- " + rs.getString("totalcgst") + " -- " + rs.getString("totalsgst")
                                    + " -- " + rs.getString("grossamt") + " -- " + rs.getString("Id"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "uomddl": {
                    String sql = "select * from uom_master";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"UOM\" autocomplete=\"off\" id=\"UOM\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select UOM</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("id") + "'>" + rs.getString("UOM_Description") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "uomddlforitemsdetails": {
                    String ItemId = request.getParameter("itemid");
                    String sql = "";
                    PrintWriter out = response.getWriter();

                    sql = "SELECT um.uom_description FROM `item_master` im left join uom_master um on (um.id=im.uom) where im.id=" + ItemId + "";

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        while (rs.next()) {

                            out.print(rs.getString("uom_description"));
                        }

                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;

                case "hsnddl": {
                    String sql = "select * from hsn_master";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"HSN_Code\" autocomplete=\"off\" id=\"HSN_Code\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option>Select HSN Code</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option>" + rs.getString("HSN_Code") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "invoiceddl": {
                    String sql = "select * from invoice";
                    PrintWriter out = response.getWriter();
                    out.print(" <select class=\"form-control\" type=\"text\" name=\"invoiceNo\" autocomplete=\"off\" id=\"invoiceNo\" onchange=\"getInvoiceDataforSalesReturn(this.value)\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Invoice No.</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("invoiceNo") + "'>" + rs.getString("invoiceNo") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;

                case "reasonddl": {
                    String sql = "select * from reason_master";
                    PrintWriter out = response.getWriter();
                    out.print("  <select class=\"form-control\" type=\"text\" name=\"reason\" autocomplete=\"off\" id=\"reason\" onchange=\"enablebtn();\" required>\n");

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery();
                        int i = 0;
                        out.print(" <option value='0'>Select Reason</option>\n");
                        while (rs.next()) {
                            i++;
                            out.print(" <option value='" + rs.getString("Reason_Description") + "'>" + rs.getString("Reason_Description") + "</option>\n");
                        }
                        out.print("</select>");
                    } catch (SQLException ex) {
                        Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;
            }
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        PrintWriter out1 = response.getWriter();

        if (null != action) {
            switch (action) {
                case "saveCustomer": {
                    String cname = request.getParameter("cname");
                    String billingaddress = request.getParameter("billingaddress");
                    String shippingaddress = request.getParameter("shippingaddress");
                    String city = request.getParameter("city");
                    String pincode = request.getParameter("pincode");
                    String state = request.getParameter("state");
                    String gstCode = request.getParameter("gstCode");
                    String gstin = request.getParameter("gstin");
                    String status = request.getParameter("status");
                    String poreq = request.getParameter("poreq");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into customer_master (Customer_Name,Billing_Address,Shipping_Address,City,State,Pincode,GST_Code,GSTIN,status,EnteredBy,EnteredDate,close) values('" + cname + "','" + billingaddress + "','" + shippingaddress + "','" + city + "','" + state + "','" + pincode + "',"
                                + "'" + gstCode + "','" + gstin + "','" + status + "','" + user + "','" + EnteredDate + "','" + poreq + "')";

                    } else {
                        sql = "update customer_master set Customer_Name='" + cname + "',Billing_Address='" + billingaddress + "',Shipping_Address='" + shippingaddress + "',"
                                + "City='" + city + "',State='" + state + "',Pincode='" + pincode + "',GST_Code='" + gstCode + "',GSTIN='" + gstin + "',status='" + status + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                if (request.getParameter("porequired") != null) {
                                    sql = "update customer_master set close = '1' where id = " + ID + "";
                                    out.print("successfully Saved");
                                } else {
                                    out.print("successfully Saved");
                                }
                            } else {
                                out.print("successfully Updated");
                            }
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveSalesOrder": {
                    String cname = request.getParameter("cname");
                    String PO_No = request.getParameter("po_no");
                    String validFrom = request.getParameter("validFrom");
                    String validTo = request.getParameter("validTo");
                    String Type = request.getParameter("Type");
                    String soDate = request.getParameter("soDate");
                    String terms = request.getParameter("terms");
                    String Status = request.getParameter("Status");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        if (PO_No.isEmpty() || PO_No.equals(null) || PO_No.equals("")) {
                            PO_No = "0";
                        }
                        sql = "insert into sales_order(Customer_Name,PO_No,validFrom,validTo,Type,soDate,terms,Status,"
                                + "EnteredBy,EnteredDate) values('" + cname + "','" + PO_No + "', '" + validFrom + "',"
                                + "'" + validTo + "','" + Type + "','" + soDate + "','" + terms + "','" + Status + "','" + user + "',"
                                + "'" + EnteredDate + "')";
                    } else {
                        if (PO_No.isEmpty() || PO_No.equals(null) || PO_No.equals("")) {
                            PO_No = "0";
                        }
                        sql = "update sales_order set Customer_Name='" + cname + "',PO_No='" + PO_No + "',validFrom='" + validFrom + "',validTo='" + validTo + "',"
                                + "Type='" + Type + "',soDate='" + soDate + "',terms='" + terms + "',Status='" + Status + "',"
                                + "RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }

                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveItemforSales": {
                    String itemName = request.getParameter("itemName");
                    String uom = request.getParameter("uom");
                    String qty = request.getParameter("qty");
                    String rate = request.getParameter("rate");
                    String user = request.getParameter("user");
                    String sorefid = request.getParameter("sorefid");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";

                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into ordered_item(itemId,sorefid,uom,quantity,rate,EnteredBy,EnteredDate) values"
                                + "(" + itemName + "," + sorefid + ",'" + uom + "', " + qty + ","
                                + "" + rate + ",'" + user + "','" + EnteredDate + "')";
                    } else {
                        sql = "update ordered_item set itemId=" + itemName + ",sorefid=" + sorefid + ",uom='" + uom + "',quantity=" + qty + ",rate="
                                + rate + ",RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";
                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }

                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "SaveHSN": {
                    String HSN_Code = request.getParameter("hsnCode");
                    String Description = request.getParameter("description");
                    String CGST = request.getParameter("cgst");
                    String SGST = request.getParameter("sgst");
                    String IGST = request.getParameter("igst");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into hsn_master(HSN_Code,Description,SGST ,CGST,IGST,EnteredBy,EnteredDate) values('" + HSN_Code + "','" + Description + "','" + SGST + "','" + CGST + "','" + IGST + "','" + user + "','" + EnteredDate + "')";

                    } else {
                        sql = "update hsn_master set HSN_Code='" + HSN_Code + "',Description='" + Description + "',SGST='" + SGST + "',CGST='" + CGST + "',IGST='" + IGST + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }

                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }
                case "saveItem": {
                    String Item_Name = request.getParameter("Item_Name");
                    String UOM = request.getParameter("UOM");
                    String HSN_Code = request.getParameter("HSN_Code");
                    String Make = request.getParameter("Make");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into item_master(Item_Name,UOM,HSN_Code,Make,EnteredBy,EnteredDate) values('" + Item_Name + "','" + UOM + "','" + HSN_Code + "','" + Make + "','" + user + "','" + EnteredDate + "')";

                    } else {
                        sql = "update item_master set Item_Name='" + Item_Name + "',UOM='" + UOM + "',HSN_Code='" + HSN_Code + "',Make='" + Make + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }

                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }
                case "SaveInvoice": {

                    String BillingAddress = request.getParameter("billingaddress");
                    String ShippingAddress = request.getParameter("shippingaddress");
                    String invoiceNo = request.getParameter("invoiceNo");
                    String customerName = request.getParameter("customerName");
                    String sorderNo = request.getParameter("sorderNo");
                    String PO_No = request.getParameter("PO_No");
                    String invoiceDate = request.getParameter("invoiceDate");
                    String terms = request.getParameter("terms");
                    String dueDate = request.getParameter("dueDate");
                    String status = request.getParameter("status");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    PrintWriter out = response.getWriter();

                    try {
                        String Sql = "";
                        if ("0".equals(ID)) {
                            if (PO_No.isEmpty() || PO_No.equals(null) || PO_No.equals("")) {
                                PO_No = "0";
                            }

                            Sql = "Insert into invoice(InvoiceNo,customerName,Billing_Address,Shipping_Address,sorderNo,PO_No,invoiceDate,terms,"
                                    + "dueDate,status,EnteredBy,EnteredDate,close)"
                                    + "values "
                                    + "('" + invoiceNo + "','" + customerName + "','" + BillingAddress + "','" + ShippingAddress + "',"
                                    + "'" + sorderNo + "','" + PO_No + "','" + invoiceDate + "'," + terms + ",'" + dueDate + "','" + status + "',"
                                    + "'" + user + "','" + EnteredDate + "','0')";
                            PreparedStatement ps = con.prepareStatement(Sql,
                                    Statement.RETURN_GENERATED_KEYS);
                            int Success = ps.executeUpdate();
                            ResultSet rs = ps.getGeneratedKeys();
                            int generatedKey = 0;
                            if (Success > 0) {
                                if (rs.next()) {
                                    generatedKey = rs.getInt(1);
                                    String ff = request.getParameter("tabledata");
                                    String converttoeasyarray = ff.replaceAll("\\[", "");
                                    converttoeasyarray = converttoeasyarray.replaceAll("\\]]", "");

                                    String[] tabledata = converttoeasyarray.split("]");
                                    int nofEntries = 0;

                                    for (String tabledata1 : tabledata) {
                                        String itemddl = "";
                                        String hsn = "";
                                        String uom = "";
                                        String Qty = "";
                                        String Rate = "";
                                        String total = "";
                                        String Discount = "";
                                        String igst = "";
                                        String cgst = "";
                                        String sgst = "";
                                        String totalamt = "";
                                        String editorinsert = "";
                                        String[] value = tabledata1.split(",");
                                        itemddl = value[0].replaceAll("\"", "");
                                        hsn = value[1].replaceAll("\"", "");
                                        uom = value[2].replaceAll("\"", "");
                                        Qty = value[3].replaceAll("\"", "");
                                        Rate = value[4].replaceAll("\"", "");
                                        total = value[5].replaceAll("\"", "");
                                        Discount = value[6].replaceAll("\"", "");
                                        igst = value[7].replaceAll("\"", "");
                                        cgst = value[8].replaceAll("\"", "");
                                        sgst = value[9].replaceAll("\"", "");
                                        totalamt = value[10].replaceAll("\"", "");
                                        editorinsert = value[11].replaceAll("\"", "");
                                        if (editorinsert.equals("form-control inserted")) {
                                            if (igst.isEmpty() || igst.equals(null) || igst.equals("")) {
                                                igst = "0.0";
                                            } else if ((cgst.isEmpty() || cgst.equals(null) || cgst.equals("")) || (sgst.isEmpty() || sgst.equals(null) || sgst.equals(""))) {
                                                cgst = "0.0";
                                                sgst = "0.0";
                                            }
                                            Sql = "Insert into invoiceitems(invoiceId,itemId,hsn,uom,Qty,Rate,total,Discount,igst,cgst,"
                                                    + "sgst,totalamt,EnteredBy,EnteredDate)"
                                                    + "values "
                                                    + "(" + generatedKey + ",'" + itemddl + "','" + hsn + "','" + uom + "'," + Qty + "," + Rate + ","
                                                    + "" + total + "," + Discount + "," + igst + "," + cgst + "," + sgst + "," + totalamt + ","
                                                    + "'" + user + "','" + EnteredDate + "')";

                                        } else {
                                            if (igst.isEmpty() || igst.equals(null) || igst.equals("")) {
                                                igst = "0.0";
                                            } else if ((cgst.isEmpty() || cgst.equals(null) || cgst.equals("")) || (sgst.isEmpty() || sgst.equals(null) || sgst.equals(""))) {
                                                cgst = "0.0";
                                                sgst = "0.0";
                                            }
                                            Sql = "Update  invoiceitems set itemId='" + itemddl + "',hsn='" + hsn + "',uom='" + uom + "',"
                                                    + "Qty=" + Qty + ",Rate=" + Rate + ",total=" + total + ",Discount=" + Discount + ","
                                                    + "igst=" + igst + ",cgst=" + cgst + ",sgst=" + sgst + ",totalamt=" + totalamt + ",RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "'"
                                                    + " where invoiceId='" + generatedKey + "' and itemId='" + itemddl + "' ";

                                        }
                                        ps = con.prepareStatement(Sql);
                                        Success = ps.executeUpdate();
                                        if (Success > 0) {

                                            nofEntries++;
                                        }
                                    }
                                    out.print(String.valueOf(nofEntries) + " Entries Saved Successfully ");
                                }

                            }
                        } else {
                            if (PO_No.isEmpty() || PO_No.equals(null) || PO_No.equals("")) {
                                PO_No = "0";
                            }
                            Sql = "Update  invoice set invoiceNo='" + invoiceNo + "',customerName='" + customerName + "',sorderNo='" + sorderNo + "',"
                                    + "PO_No='" + PO_No + "',invoiceDate='" + invoiceDate + "',terms=" + terms + ",dueDate='" + dueDate + "',"
                                    + "status='" + status + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + " ";

                            PreparedStatement ps = con.prepareStatement(Sql);
                            int Success = ps.executeUpdate();
                            if (Success > 0) {

                                String ff = request.getParameter("tabledata");
                                String converttoeasyarray = ff.replaceAll("\\[", "");
                                converttoeasyarray = converttoeasyarray.replaceAll("\\]]", "");

                                String[] tabledata = converttoeasyarray.split("]");
                                int nofEntries = 0;

                                for (String tabledata1 : tabledata) {
                                    String itemddl = "";
                                    String hsn = "";
                                    String uom = "";
                                    String Qty = "";
                                    String Rate = "";
                                    String total = "";
                                    String Discount = "";
                                    String igst = "";
                                    String cgst = "";
                                    String sgst = "";
                                    String totalamt = "";
                                    String editorinsert = "";
                                    String[] value = tabledata1.split(",");
                                    itemddl = value[0].replaceAll("\"", "");
                                    hsn = value[1].replaceAll("\"", "");
                                    uom = value[2].replaceAll("\"", "");
                                    Qty = value[3].replaceAll("\"", "");
                                    Rate = value[4].replaceAll("\"", "");
                                    total = value[5].replaceAll("\"", "");
                                    Discount = value[6].replaceAll("\"", "");
                                    igst = value[7].replaceAll("\"", "");
                                    cgst = value[8].replaceAll("\"", "");
                                    sgst = value[9].replaceAll("\"", "");
                                    totalamt = value[10].replaceAll("\"", "");
                                    editorinsert = value[11].replaceAll("\"", "");
                                    if (editorinsert.equals("form-control inserted")) {
                                        if (igst.isEmpty() || igst.equals(null) || igst.equals("")) {
                                            igst = "0.0";
                                        } else if ((cgst.isEmpty() || cgst.equals(null) || cgst.equals("")) || (sgst.isEmpty() || sgst.equals(null) || sgst.equals(""))) {
                                            cgst = "0.0";
                                            sgst = "0.0";
                                        }
                                        Sql = "Insert into invoiceitems(invoiceId,itemId,hsn,uom,Qty,Rate,total,Discount,igst,cgst,"
                                                + "sgst,totalamt,EnteredBy,EnteredDate)"
                                                + "values "
                                                + "(" + ID + ",'" + itemddl + "','" + hsn + "','" + uom + "'," + Qty + "," + Rate + ","
                                                + "" + total + "," + Discount + "," + igst + "," + cgst + "," + sgst + "," + totalamt + ","
                                                + "'" + user + "','" + EnteredDate + "')";

                                    } else {
                                        if (igst.isEmpty() || igst.equals(null) || igst.equals("")) {
                                            igst = "0.0";
                                        } else if ((cgst.isEmpty() || cgst.equals(null) || cgst.equals("")) || (sgst.isEmpty() || sgst.equals(null) || sgst.equals(""))) {
                                            cgst = "0.0";
                                            sgst = "0.0";
                                        }
                                        Sql = "Update  invoiceitems set itemId='" + itemddl + "',hsn='" + hsn + "',"
                                                + "uom='" + uom + "',Qty=" + Qty + ",Rate=" + Rate + ",total=" + total + ",Discount=" + Discount + ","
                                                + "igst=" + igst + ",cgst=" + cgst + ",sgst=" + sgst + ",totalamt=" + totalamt + ",RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "'"
                                                + " where invoiceId=" + ID + " and itemId='" + itemddl + "' ";
                                    }
                                    ps = con.prepareStatement(Sql);
                                    Success = ps.executeUpdate();
                                    if (Success > 0) {

                                        nofEntries++;
                                    }
                                }
                                out.print(String.valueOf(nofEntries) + " Entries Updated Successfully ");
                            }
                        }
                    } catch (Exception ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveSetup": {
                    String CompanyName = request.getParameter("CompanyName");
                    String MobileNo = request.getParameter("MobileNo");
                    String Email = request.getParameter("Email");
                    String State = request.getParameter("State");
                    String statecode = request.getParameter("statecode");
                    String GSTIN = request.getParameter("GSTIN");
                    String PanNo = request.getParameter("PanNo");
                    String Address = request.getParameter("Address");
                    String acname = request.getParameter("acname");
                    String bankname = request.getParameter("bankname");
                    String bname = request.getParameter("bname");
                    String acnumber = request.getParameter("acnumber");
                    String ifsc = request.getParameter("ifsc");
                    String Id = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if (checkCompanySetup()) {
                        sql = "update setup set CompanyName='" + CompanyName + "',MobileNo='" + MobileNo + "',Email='" + Email + "',State='" + State + "',statecode='" + statecode + "'"
                                + "GSTIN='" + GSTIN + "',PanNo='" + PanNo + "'," + "Address='" + Address + "',Account_Name='" + acname + "',Bank_Name='" + bankname + "',"
                                + "Branch_Name='" + bname + "',Account_No='" + acnumber + "',IFSC_Code='" + ifsc + "' where Id='1'";

                    } else {
                        sql = "insert into setup(CompanyName,MobileNo,Email,State,statecode,GSTIN,PanNo,Address,Account_Name,Bank_Name,Branch_Name,Account_No,"
                                + "IFSC_Code) values('" + CompanyName + "','" + MobileNo + "','" + Email + "','" + State + "','" + statecode + "','" + GSTIN + "','" + PanNo
                                + "','" + Address + "','" + acname + "','" + bankname + "','" + bname + "','" + acnumber + "','" + ifsc + "')";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("1".equals(Id)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }
                case "saveUOM": {
                    String UOM_Code = request.getParameter("UOM_Code");
                    String UOM_Description = request.getParameter("UOM_Description");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into uom_master(UOM_Code,UOM_Description,EnteredBy,EnteredDate) values('" + UOM_Code + "','" + UOM_Description + "','" + user + "','" + EnteredDate + "')";

                    } else {
                        sql = "update uom_master set UOM_Code='" + UOM_Code + "',UOM_Description='" + UOM_Description + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }

                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveReason": {
                    String Reason_Description = request.getParameter("Reason_Description");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    if ("0".equals(ID)) {
                        sql = "insert into reason_master(Reason_Description,EnteredBy,EnteredDate) values('" + Reason_Description + "','" + user + "','" + EnteredDate + "')";

                    } else {
                        sql = "update reason_master set Reason_Description='" + Reason_Description + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";

                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }

                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "savePayment": {
                    String invoiceId = request.getParameter("invoiceId");
                    String receivedDate = request.getParameter("receivedDate");
                    String receivedAmount = request.getParameter("receivedAmount");
                    String ModeOfPayment = request.getParameter("ModeOfPayment");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();

                    if ("0".equals(ID)) {
                        sql = "insert into received (invoiceId,receivedAmount,receivedDate,ModeOfPayment,EnteredBy,EnteredDate) "
                                + "values(" + invoiceId + "," + receivedAmount + ",'" + receivedDate + "','" + ModeOfPayment + "','" + user + "','" + EnteredDate + "')";
                    } else {
                        sql = "update received set receivedAmount=" + receivedAmount + ",receivedDate='" + receivedDate + "',ModeOfPayment='" + ModeOfPayment + "',RevisedBy='" + user + "',RevisedDate='" + RevisedDate + "' where id=" + ID + "";
                    }

                    try {

                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if (("0".equals(ID))) {
                                sql = "update invoice set close='1' where Id=" + invoiceId + "";
                                ps = con.prepareStatement(sql);
                                success = ps.executeUpdate();
                                if (success > 0) {
                                    out.print("Successfully Saved");
                                }
                            } else {
                                out.print("Successfully Updated");
                            }

                        } else {
                            out.print("Not Saved");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "saveSalesReturn": {
                    String invoiceNo = request.getParameter("invoiceNo");
                    String customerName = request.getParameter("customerName");
                    String invoiceDate = request.getParameter("invoiceDate");
                    String orderNo = request.getParameter("orderNo");
                    String Billing_Address = request.getParameter("Billing_Address");
                    String netvalue = request.getParameter("netvalue");
                    String gstvalue = request.getParameter("gstvalue");
                    String grossvalue = request.getParameter("grossvalue");
                    String reason = request.getParameter("reason");
                    String user = request.getParameter("user");
                    java.sql.Timestamp EnteredDate = new java.sql.Timestamp(curDate.getTime());
                    java.sql.Timestamp RevisedDate = new java.sql.Timestamp(curDate.getTime());
                    String ID = request.getParameter("Id");

                    String sql = "";

                    PrintWriter out = response.getWriter();

                    if ("0".equals(ID)) {
                        sql = "insert into salesreturn (invoiceNo,customerName,invoiceDate,orderNo,Billing_Address,"
                                + "netvalue,gstvalue,grossvalue,reason,EnteredBy,EnteredDate) "
                                + "values('" + invoiceNo + "','" + customerName + "','" + invoiceDate + "'," + orderNo + ",'" + Billing_Address + "'," + netvalue + "," + gstvalue + ","
                                + "" + grossvalue + ",'" + reason + "','" + user + "','" + EnteredDate + "')";
                    } else {
                        sql = "update salesreturn set invoiceNo='" + invoiceNo + "',customerName='" + customerName + "',invoiceDate='" + invoiceDate + "',"
                                + "orderNo='" + orderNo + "',Billing_Address='" + Billing_Address + "',netvalue='" + netvalue + "',"
                                + "gstvalue='" + gstvalue + "',grossvalue='" + grossvalue + "',reason='" + reason + "',RevisedBy='" + user + "',"
                                + "RevisedDate='" + RevisedDate + "' where id=" + ID + "";
                    }

                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            if ("0".equals(ID)) {
                                out.print("successfully Saved");
                            } else {
                                out.print("successfully Updated");
                            }

                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                    break;
                }

                case "Delete": {

                    String table = request.getParameter("tbl");

                    String ID = request.getParameter("Id");
                    String sql = "";
                    PrintWriter out = response.getWriter();
                    sql = "Delete from " + table + " where id=" + ID + "";
                    try {
                        PreparedStatement ps = con.prepareStatement(sql);
                        int success = ps.executeUpdate();
                        if (success > 0) {
                            out.print("Data deleted Successfully");
                        }
                    } catch (SQLException ex) {
                        out.print(ex);
                    }
                }
                break;
                default:
                    break;
            }
        }
    }

    private boolean checkCompanySetup() {
        String sql = "";

        sql = "select * from setup where Id=1";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                return true;

            }

        } catch (SQLException ex) {
            Logger.getLogger(billingServlet.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    private String itemdropdownhtml(String inputid, String itemid) {
        String sql = "select * from item_master";
        String htmlcode = "";
        htmlcode = htmlcode + " <select class=\"chosen\" id=\"itemddl" + inputid + "\" style=\"width: 170px;\" onChange=\"getHsnCode(this.value,this.id)\">\n";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            int i = 0;
            htmlcode = htmlcode + " <option>Select Item</option>\n";
            while (rs.next()) {
                i++;
                if (rs.getString("id").equals(itemid)) {
                    htmlcode = htmlcode + " <option value='" + rs.getString("id") + "' selected>" + rs.getString("Item_Name") + "</option>\n";
                } else {
                    htmlcode = htmlcode + " <option value='" + rs.getString("id") + "'>" + rs.getString("Item_Name") + "</option>\n";
                }

            }
            htmlcode = htmlcode + "</select>";

        } catch (SQLException ex) {
            Logger.getLogger(billingServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        return htmlcode;
    }
}
